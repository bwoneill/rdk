#include "Smoother.h"
#include "TMath.h"
#include "TMatrixD.h"
using namespace TMath;

Smoother::Smoother(unsigned int r){
	vectors=NULL;
	setR(r);
}

Smoother::~Smoother(){
	clean();
}

void Smoother::setR(unsigned int r){
	if(vectors!=NULL){
		delete[] vectors;
	}
	radius=r;
	size=2*radius+1;
	clean();
	vectors=new TVectorD[size];
	for(int i=0;i<size;i++){
		int offset=Abs((int)(radius-i)),dim=size-offset;
		vectors[i].ResizeTo(dim);
		TMatrixD x(dim,2),unit(1,2);
		unit[0][0]=1;
		unit[0][1]=0;
		TMatrixD w(dim,dim);
		for(int j=0;j<dim;j++){
			x[j][0]=1;
			x[j][1]=j-i;
			if(i>radius){
				x[j][1]+=offset;
			}
			w[j][j]=Power(radius+1,3)-Abs(Power(x[j][1],3));
		}
		TMatrixD xT(2,dim);
		xT.Transpose(x);
		TMatrixD xTwx(xT*w*x);
		xTwx.Invert();
		vectors[i]=(unit*xTwx*xT*w)[0];
	}
	//vectors[radius].Print();
}

TVectorD Smoother::smooth(const TVectorD &in) const{
	int dim=in.GetNrows(),upr=2*radius-dim+1;
	TVectorD out(dim);
	for(int i=0;i<dim;i++){
		if(i<=radius){
			out[i]=in.GetSub(0,i+radius)*vectors[i];
		}else if(i<dim-radius){
			out[i]=in.GetSub(i-radius,i+radius)*vectors[radius];
		}else{
			out[i]=in.GetSub(i-radius,dim-1)*vectors[i+upr];
		}
	}
	return out;
}

void Smoother::clean(){
	if(vectors!=NULL){
		delete[] vectors;
	}
}