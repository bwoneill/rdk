//Smoother.h

#ifndef SMOOTHER_H
#define SMOOTHER_H

#include "TVectorD.h"

class Smoother{
private:
	unsigned int radius,size;
	TVectorD *vectors;
	void clean();
public:
	Smoother(unsigned int=0);
	~Smoother();
	void setR(unsigned int);
	TVectorD smooth(const TVectorD&)const;
};

#endif