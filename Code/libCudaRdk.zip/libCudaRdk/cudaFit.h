//cudaFit.h

#ifndef CUDAFIT_H
#define CUDAFIT_H

class cudaFit{
private:
	float *y_h,*x_h,*C_h,*chi2_h,*gradChi2_h;	//host storage
	float *y_d,*x_d,*C_d,*chi2_d,*gradChi2_d;	//device storage accesable by host
	float *p,*alpha,*delta,*gamma,*resF,*gradF;	//device only storage
	float *x1,*x2,*c1,*c2,*gc1,*gc2;
	float *lambda,*theta,*phi,*mu,*psi;
	float *debug;
	int N;
	void calcStats(float*,float*,const float*);
public:
	cudaFit(int);
	~cudaFit();
	enum DebugMode{kP,kAlpha,kDelta,kGamma,kRes,kGrad,kY_h,kY_d};
	void setData(const float**);
	void fit(const float*,int);
	void getParameters(float**);
	void getCovariance(float***);
	void getChi2(float*);
	void getGradChi2(float**);
	void getDebug(float*,DebugMode);
};

#endif