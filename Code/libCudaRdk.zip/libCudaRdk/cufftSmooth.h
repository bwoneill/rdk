//cufftSmooth.h

#ifndef CUFFTSMOOTH_H
#define CUFFTSMOOTH_H

#ifndef __CINT__
#include <cufft.h>
#else
class cufftHandle;
class cufftComplex;
#endif

#include "Rtypes.h"

class cufftSmooth{
private:
	cufftHandle forward,backward;
	cufftComplex *h_signal,*h_filter,*d_signal,*d_filter;
	Int_t size,batch,memsize,datsize,batchsize,device,nBlocks,nThreads;
	Double_t radius;
	void clean();
public:
	cufftSmooth(Int_t=0,Double_t r=1,Int_t=1);
	~cufftSmooth();
	void init(Int_t,Double_t,Int_t);
	void setSignal(const Double_t*,Int_t);
	void getSignal(Double_t*,Int_t)const;
	void smooth();
	Double_t sigma_v()const;
	Double_t sigma_h()const;
	static void Benchmark(Int_t,Int_t=1);
};

#endif