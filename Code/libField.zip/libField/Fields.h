//Fields.h

#ifndef FIELDS_H
#define FIELDS_H

#include "TVector3.h"
#include "TFile.h"
#include "TTree.h"

#include <vector>
using std::vector;

class FieldMap{
public:
	virtual Long64_t hash(const TVector3&) const=0;
	virtual Long64_t getMax() const=0;
	virtual bool inMap(const TVector3&) const=0;
	virtual const Long64_t* getNeighbors(const TVector3&,Double_t *) const=0;
};

class MappedField{
protected:
	const FieldMap *map;
	Double_t **data;
	Long64_t getIndex(const TVector3&) const;
	void fill(TTree*);
public:
	MappedField(const FieldMap*,Int_t,TTree* =NULL);
	MappedField(const FieldMap*,Int_t,TFile*,const TString&);
	~MappedField();
	void set(const TVector3&,const Double_t*);
	inline const FieldMap* getMap() const {return map;}
	inline bool inMap(const TVector3 &v) const {return map->inMap(v);}
	inline Long64_t getMax() const {return map->getMax();}
	void save(const Char_t*,const Char_t*,const Char_t*) const;
	const Double_t* at(Int_t i) const{return data[i];}
	const Int_t DIM;
};

class ScalarField: public MappedField{
public:
	ScalarField(const FieldMap *m,TTree *t=NULL):MappedField(m,1,t){}
	ScalarField(const FieldMap *m,TFile *f,const TString &name):MappedField(m,1,f,name){}
	Double_t get(const TVector3&) const;
	Double_t getNearest(const TVector3&) const;
	void set(const TVector3 &v,Double_t x){MappedField::set(v,&x);}
	void save(const Char_t* file,const Char_t* name="sf") const;
};

class VectorField: public MappedField{
public:
	VectorField(const FieldMap *m,TTree *t=NULL):MappedField(m,3,t){}
	VectorField(const FieldMap *m,TFile *f,const TString &name):MappedField(m,3,f,name){}
	TVector3 get(const TVector3&) const;
	TVector3 getNearest(const TVector3&) const;
	void set(const TVector3&,const TVector3&);
	void save(const Char_t* file,const Char_t* name="vf") const;
};

class FieldReader{
private:
	Double_t **table;
	MappedField *field;
	Long64_t count;
public:
	FieldReader(MappedField*);
	~FieldReader();
	Int_t read(const Char_t*);
};

#endif