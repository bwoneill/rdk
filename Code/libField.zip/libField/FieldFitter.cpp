//FieldFitter.cpp

#include "FieldFitter.h"
#include "RDKTypes.h"
#include "TMath.h"

#include <iostream>
using namespace std;

using namespace TMath;

BorePotFitter::BorePotFitter(ScalarField *p1,ScalarField *p2,Int_t n):pot1(p1),pot2(p2),N((n+1)*(n+2)*(n+3)/6){
	param.ResizeTo(N);
	expo.ResizeTo(N,3);
	Int_t i=0;
	for(Int_t a=0;a<=n;a++){
		for(Int_t b=0;a+b<=n;b++){
			for(Int_t c=0;a+b+c<=n;c++){
				expo[i][0]=a;
				expo[i][1]=b;
				expo[i][2]=c;
				i++;
			}
		}
	}
}

void BorePotFitter::fit(){
	TMatrixD xtx(N,N);
	TVectorD xty(N);
	Double_t y=0,y2=0;
	fill(xtx,xty,pot1,y,y2);
	fill(xtx,xty,pot2,y,y2);
	xtx=xtx.Invert();
	param=xtx*xty;
	chi2=y2-xty*param;
	sigma2=y2-y*y/(pot1->getMap()->getMax()+pot2->getMap()->getMax());
}

void BorePotFitter::fill(TMatrixD &xtx,TVectorD &xty,const ScalarField *pot,Double_t &y,Double_t &y2) const{
	Int_t n=pot->getMap()->getMax();
	TVector3 v;
	for(Int_t a=0;a<n;a++){
		const Double_t* vector=pot->at(a);
		TVector3 v(vector);
		const Double_t value=vector[3];
		y+=value;
		y2+=value*value;
		TVectorD x(N);
		for(Int_t i=0;i<N;i++){
			x[i]=eval(v,i);
		}
		for(Int_t i=0;i<N;i++){
			for(Int_t j=0;j<N;j++){
				xtx(i,j)+=x[i]*x[j];
			}
			xty[i]+=x[i]*value;
		}
	}
}

bool BorePotFitter::inBoth(const TVector3 &v) const{
	return pot1->getMap()->inMap(v) && pot2->getMap()->inMap(v);
}

Double_t BorePotFitter::evaluate(const TVector3 &v) const{
	Double_t value=0;
	for(Int_t i=0;i<N;i++){
		value+=param[i]*eval(v,i);
	}
	return value;
}

Double_t BorePotFitter::eval(const TVector3 &v,Int_t i) const{
	Double_t value=1,vector[3];
	v.GetXYZ(vector);
	for(Int_t j=0;j<3;j++){
		value*=Power(vector[j],expo[i][j]);
	}
	return value;
}

TVector3 BorePotFitter::buildVector(Double_t r,Double_t phi,Double_t z,const ScalarField *pot){
	TVector3 v(r,0,z);
	v.RotateZ(DegToRad()*phi);
	BoreMap *map=(BoreMap*)pot->getMap();
	v.RotateY(map->getPsi());
	return v;
}

void BorePotFitter::save(TString file) const{
	TFile f(file,"update");
	f.WriteTObject(&param,"parameters","overwrite");
	f.Close();
}

void BorePotFitter::load(TString file){
	TFile f(file);
	TVectorD *temp=(TVectorD*)f.Get("parameters");
	param=*temp;
	delete temp;
	f.Close();
}

TVector3 BorePotFitter::grad(const TVector3 &v) const{
	Double_t vector[3],result[3]={0,0,0};
	v.GetXYZ(vector);
	for(Int_t i=0;i<3;i++){
		for(Int_t j=0;j<N;j++){
			Double_t temp=1;
			for(Int_t k=0;k<3;k++){
				if(i==k){
					if(expo[j][k]==0){
						temp=0;
						break;
					}
					temp*=expo[j][k]*Power(vector[k],expo[j][k]-1);
				}else{
					temp*=Power(vector[k],expo[j][k]);
				}
			}
			result[i]+=temp;
		}
	}
	return TVector3(result);
}