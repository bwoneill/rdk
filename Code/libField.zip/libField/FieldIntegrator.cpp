//FieldIntegrator.cpp

#include "FieldIntegrator.h"
#include "TMath.h"
using namespace TMath;

FieldIntegrator::FieldIntegrator(VectorField *v):field(v){
	potential=new ScalarField(field->getMap());
}

BoreInt::BoreInt(VectorField *v,Double_t PSI):FieldIntegrator(v),psi(DegToRad()*PSI){}

void BoreInt::integrate(){
	potential->set(TVector3(0,0,0),0.0);
	axial();
}

void BoreInt::axial(){
	TVector3 rel,here,prev;
	for(Double_t z=-0.25;z>=-2;z-=0.25){
		prev=here;
		rel.SetZ(z);
		here=rel;
		here.RotateY(psi);
		TVector3 delta=here-prev;
		potential->set(here,potential->get(prev)+field->get(prev).Dot(delta));
		polar(rel);
	}
	here=TVector3(0,0,0);
	for(Double_t z=0.25;z<=58;z+=0.25){
		prev=here;
		rel.SetZ(z);
		here=rel;
		here.RotateY(psi);
		TVector3 delta=here-prev;
		potential->set(here,potential->get(prev)+field->get(prev).Dot(delta));
		polar(rel);
	}
}

void BoreInt::polar(const TVector3 &v){
	for(Int_t phi=0;phi<360;phi+=2){
		radial(v,DegToRad()*phi);
	}
}

void BoreInt::radial(const TVector3 &v,Double_t phi){
	TVector3 rel(v),here(v),prev;
	here.RotateY(psi);
	for(Float_t r=0.25;r<=7;r+=0.25){
		prev=here;
		if(rel.Perp()>0){
			rel.SetPerp(r);
		}else{
			rel.SetX(r);
			rel.RotateZ(phi);
		}
		here=rel;
		here.RotateY(psi);
		TVector3 delta=here-prev;
		potential->set(here,potential->get(prev)+field->get(prev).Dot(delta));
	}
}