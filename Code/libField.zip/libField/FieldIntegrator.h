//FieldIntegrator.h

#ifndef FIELDINTEGRATOR_H
#define FIELDINTEGRATOR_H

#include "Fields.h"

class FieldIntegrator{
protected:
	VectorField *field;
	ScalarField *potential;
public:
	FieldIntegrator(VectorField*);
	inline ScalarField *getPotential(){return potential;}
	virtual void integrate()=0;
};

class BoreInt: public FieldIntegrator{
private:
	void axial();
	void polar(const TVector3&);
	void radial(const TVector3&,Double_t phi);
	Double_t psi;
public:
	BoreInt(VectorField *v,Double_t psi=0);
	void integrate();
};

#endif