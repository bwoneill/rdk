//FieldFitter.h

#ifndef FIELDFITTER_H
#define FIELDFITTER_H

#include "Fields.h"
#include "BoreMapper.h"
#include "TMatrixD.h"
#include "TVectorD.h"

class BorePotFitter{
private:
	ScalarField *pot1,*pot2;
	TVectorD param;
	TMatrixD expo;
	const Int_t N;
	Double_t chi2,sigma2;
	static TVector3 buildVector(Double_t,Double_t,Double_t,const ScalarField*);
	Double_t eval(const TVector3&,Int_t)const;
	void fill(TMatrixD&,TVectorD&,const ScalarField*,Double_t&,Double_t&) const;
public:
	BorePotFitter(ScalarField*,ScalarField*,Int_t);
	~BorePotFitter(){}
	void fit();
	bool inBoth(const TVector3&) const;
	Double_t evaluate(const TVector3&) const;
	TVector3 grad(const TVector3&) const;
	const TVectorD& getParam() const {return param;}
	void save(TString) const;
	void load(TString);
	Double_t getChi2() const {return chi2;}
	Double_t getSigma2() const {return sigma2;}
	Double_t getR2() const {return 1-chi2/sigma2;}
	Double_t getF() const {return getR2()*(pot1->getMap()->getMax()+pot2->getMap()->getMax()-N)/((1-getR2())*(N-1));}
};

#endif