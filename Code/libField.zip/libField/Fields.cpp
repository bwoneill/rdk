//VectorField.cpp

#include "Fields.h"
#include "RDKTypes.h"
#include "TMath.h"
#include "TString.h"
#include "TObjArray.h"
#include "TObjString.h"

#include <iostream>
#include <fstream>
using namespace std;

MappedField::MappedField(const FieldMap *m,Int_t dim,TTree *tree):map(m),DIM(dim){
	data=new Double_t*[map->getMax()];
	for(Int_t i=0;i<map->getMax();i++){
		data[i]=new Double_t[dim+3];
		for(Int_t j=0;j<dim+3;j++){
			data[i][j]=0;
		}
	}
	fill(tree);
}

MappedField::MappedField(const FieldMap *m,Int_t dim,TFile *f,const TString &name):map(m),DIM(dim){
	data=new Double_t*[map->getMax()];
	for(Int_t i=0;i<map->getMax();i++){
		data[i]=new Double_t[dim+3];
		for(Int_t j=0;j<dim+3;j++){
			data[i][j]=0;
		}
	}
	TTree *tree=(TTree*)f->Get(name);
	fill(tree);
}

MappedField::~MappedField(){
	delete[] data;
	delete map;
}

Long64_t MappedField::getIndex(const TVector3 &v) const{
	Long64_t i=map->hash(v);
	if(i<0 || i>=map->getMax()){
		throw RDKException(Form("Unable to hash coordinate (%f,%f,%f)",v.x(),v.y(),v.z()));
	}
	return i;
}

void MappedField::fill(TTree *tree){
	if(tree==NULL){
		return;
	}
	Double_t *buff=new Double_t[DIM+3];
	tree->SetBranchAddress("point",buff);
	tree->SetBranchAddress("value",buff+3);
	Long64_t max=TMath::Min(map->getMax(),tree->GetEntries());
	for(Int_t i=0;i<max;i++){
		tree->GetEntry(i);
		set(TVector3(buff),buff+3);
	}
	delete[] buff;
}

void MappedField::save(const Char_t *file,const Char_t *name,const Char_t *title) const{
	TFile *out=new TFile(file,"update");
	TTree *tree=new TTree(name,title);
	Double_t *buff=new Double_t[DIM+3];
	tree->Branch("point",buff,"x/D:y:z");
	tree->Branch("value",buff+3,Form("value[%i]/D",DIM));
	for(Long64_t i=0;i<map->getMax();i++){
		TVector3 v(data[i]);
		if(v.Mag()==0 && i!=0){
			continue;
		}
		for(Int_t j=0;j<DIM+3;j++){
			buff[j]=data[i][j];
		}
		tree->Fill();
	}
	tree->Write(0,TObject::kOverwrite);
	out->Close();
}

void MappedField::set(const TVector3 &v,const Double_t *x){
	Long64_t index=getIndex(v);
	v.GetXYZ(data[index]);
	for(Int_t i=0;i<DIM;i++){
		data[index][3+i]=x[i];
	}
}

Double_t ScalarField::getNearest(const TVector3 &v) const{
	return data[getIndex(v)][3];
}

Double_t ScalarField::get(const TVector3 &v) const{
	Double_t rel[3],weight[8];
	const Long64_t *neighbors=map->getNeighbors(v,rel);
	weight[0]=(1-rel[0])*(1-rel[1])*(1-rel[2]);
	weight[1]=rel[0]*(1-rel[1])*(1-rel[2]);
	weight[2]=rel[0]*(1-rel[1])*rel[2];
	weight[3]=(1-rel[0])*(1-rel[1])*rel[2];
	weight[4]=(1-rel[0])*rel[1]*(1-rel[2]);
	weight[5]=rel[0]*rel[1]*(1-rel[2]);
	weight[6]=rel[0]*rel[1]*rel[2];
	weight[7]=(1-rel[0])*rel[1]*rel[2];
	Double_t result=0;
	for(Int_t i=0;i<8;i++){
		result+=weight[i]*data[neighbors[i]][3];
	}
	delete neighbors;
	return result;
}

void ScalarField::save(const Char_t* file,const Char_t* name) const{
	MappedField::save(file,name,"Scalar field");
}

TVector3 VectorField::getNearest(const TVector3 &v) const{
	return TVector3(data[getIndex(v)]+3);
}

TVector3 VectorField::get(const TVector3 &v) const{
	Double_t rel[3],weight[8];
	const Long64_t *neighbors=map->getNeighbors(v,rel);
	weight[0]=(1-rel[0])*(1-rel[1])*(1-rel[2]);
	weight[1]=rel[0]*(1-rel[1])*(1-rel[2]);
	weight[2]=rel[0]*(1-rel[1])*rel[2];
	weight[3]=(1-rel[0])*(1-rel[1])*rel[2];
	weight[4]=(1-rel[0])*rel[1]*(1-rel[2]);
	weight[5]=rel[0]*rel[1]*(1-rel[2]);
	weight[6]=rel[0]*rel[1]*rel[2];
	weight[7]=(1-rel[0])*rel[1]*rel[2];
	TVector3 result;
	for(Int_t i=0;i<8;i++){
		result+=weight[i]*TVector3(data[neighbors[i]]+3);
	}
	delete neighbors;
	return result;
}

void VectorField::set(const TVector3 &v1,const TVector3 &v2){
	Double_t buff[3];
	v2.GetXYZ(buff);
	MappedField::set(v1,buff);
}

void VectorField::save(const Char_t* file,const Char_t* name) const{
	MappedField::save(file,name,"Vector Field");
}

FieldReader::FieldReader(MappedField *f):field(f),count(0){
	const FieldMap *map=field->getMap();
	table=new Double_t*[map->getMax()];
	for(Int_t i=0;i<map->getMax();i++){
		table[i]=new Double_t[3+field->DIM];
		for(Int_t j=0;j<4;j++){
			table[i][j]=0;
		}
	}
}

FieldReader::~FieldReader(){
	delete[] table;
}

Int_t FieldReader::read(const Char_t* file){
	ifstream in(file);
	TString line;
	Double_t *buff=new Double_t[3+field->DIM];
	while(in.good()){
		line.ReadLine(in);
		TObjArray *list=line.Tokenize(" ");
		if(list->GetEntries()==3+field->DIM){
			count++;
			for(Int_t ncol=0;ncol<3+field->DIM;ncol++){
				TObjString *temp=(TObjString*)list->At(ncol);
				TString value=temp->String();
				buff[ncol]=value.Atof();
			}
			TVector3 point(buff);
			Long64_t hash=field->getMap()->hash(point);
			if(hash>=field->getMap()->getMax() || hash<0){
				cout<<"Invalid hash="<<hash<<" for vector "<<count<<endl;
				point.Print();
			}else{
				if(table[hash][0]!=0){
					TVector3 temp(table[hash]+1);
					if((temp-point).Mag()>1e-3){
						cout<<"Vectors "<<table[hash][0]<<" and "<<count<<" collide at hash="<<hash<<endl;
						temp.Print();
						point.Print();
					}
				}
				table[hash][0]=count;
				for(Int_t i=0;i<3;i++){
					table[hash][i+1]=buff[i];
				}
				field->set(point,buff+3);
			}
		}
		list->Delete();
	}
	in.close();
	delete buff;
	return count;
}