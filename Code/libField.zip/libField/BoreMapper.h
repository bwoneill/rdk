//BoreMapper.h

#ifndef BOREMAPPER_H
#define BOREMAPPER_H

#include "Fields.h"

class BoreMap: public FieldMap{
private:
	const Double_t psi;
	static const Long64_t deltaR,deltaPhi;
public:
	BoreMap(Double_t=0);		//angle of deflection in degrees, 180 for streight, 9.5 for bend
	Long64_t hash(const TVector3&) const;
	Long64_t getMax() const {return max;}
	bool inMap(const TVector3&) const;
	const Long64_t* getNeighbors(const TVector3&,Double_t*) const;
	Double_t getPsi() const {return -psi;}
	static const Long64_t max;
	static bool DEBUG;
};

ScalarField **openScalarPot(TString);
VectorField **openMagField(TString);

#endif