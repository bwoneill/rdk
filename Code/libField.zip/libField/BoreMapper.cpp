//BoreMapper.cpp

#include "BoreMapper.h"
#include "TFile.h"
#include "TMath.h"
using namespace TMath;

#include <iostream>
using namespace std;

BoreMap::BoreMap(Double_t Psi):psi(-DegToRad()*Psi){}

Long64_t BoreMap::hash(const TVector3 &v) const{
	TVector3 rel(v);
	rel.RotateY(psi);
	Int_t R=Nint(4*rel.Perp()),Phi=Nint(RadToDeg()*rel.Phi()),Z=Nint(4*rel.z());
	while(Phi<0){
		Phi+=360;
	}
	while(Phi>=360){
		Phi-=360;
	}
	if(DEBUG){
		cout<<"R="<<0.25*R<<endl;
		cout<<"Phi="<<Phi<<endl;
		cout<<"Z="<<0.25*Z<<endl;
	}
	return R==0?Z+8:43380*(R-1)+241*(Phi/2+1)+Z+8;
}

bool BoreMap::inMap(const TVector3 &v) const{
	TVector3 rel(v);
	rel.RotateY(psi);
	Int_t R=Nint(4*rel.Perp()),Z=Nint(4*rel.z());
	return R<=28 && Z>=-8 && Z<=58;
}

const Long64_t* BoreMap::getNeighbors(const TVector3 &v,Double_t *coord) const{
	TVector3 rel(v);
	rel.RotateY(psi);
	Int_t R=Floor(4*rel.Perp()),Phi=Floor(RadToDeg()*rel.Phi()),Z=Floor(4*rel.Z());
	while(Phi<0){
		Phi+=360;
	}
	while(Phi>=360){
		Phi-=360;
	}
	if(Z==58){
		Z--;
	}
	Long64_t dR=R==0?deltaPhi*(Phi/2+1):deltaR;
	Long64_t dPhi2=deltaPhi-(deltaPhi==358)*deltaR,dPhi1=R==0?0:dPhi2;
	Long64_t *result=new Long64_t[8];
	result[0]=R==0?Z+8:43380*(R-1)+241*(Phi/2+1)+Z+8;
	result[1]=result[0]+dR;
	result[2]=result[1]+1;
	result[3]=result[0]+1;
	result[4]=result[0]+dPhi1;
	result[5]=result[1]+dPhi2;
	result[6]=result[5]+1;
	result[7]=result[4]+1;
	coord[0]=4*rel.Perp()-R;
	coord[1]=(rel.Phi()-Phi)/2;
	coord[2]=4*rel.Z()-Z;
	return result;
}

const Long64_t BoreMap::deltaR=43380;
const Long64_t BoreMap::deltaPhi=241;
const Long64_t BoreMap::max=1214881;
bool BoreMap::DEBUG=false;

ScalarField** openScalarPot(TString f){
	ScalarField **fields=new ScalarField*[2];
	TFile *file=new TFile(f);
	fields[0]=new ScalarField(new BoreMap(180),file,"potential-180");
	fields[1]=new ScalarField(new BoreMap(9.5),file,"potential-9.5");
	file->Close();
	return fields;
}

VectorField** openMagField(TString f){
	VectorField **fields=new VectorField*[2];
	TFile *file=new TFile(f);
	fields[0]=new VectorField(new BoreMap(180),file,"bfield-180");
	fields[1]=new VectorField(new BoreMap(9.5),file,"bfield-9.5");
	file->Close();
	return fields;
}