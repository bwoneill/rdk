//HaarWavelet.h

#ifndef HAARWAVELET_H
#define HAARWAVELET_H

#include <vector>

class HaarWavelet{
private:
	std::vector<double> temp,buff;
	unsigned int length,log2length;
public:
	HaarWavelet(unsigned int);
	~HaarWavelet();
	void full_dwt(const std::vector<double>&,std::vector<double>&);
	void full_idwt(const std::vector<double>&,std::vector<double>&);
};

#endif