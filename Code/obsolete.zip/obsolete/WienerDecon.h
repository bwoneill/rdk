//WienerDecon.h

#ifndef WIENERDECON_H
#define WIENERDECON_H

#include "TString.h"
#include "TComplex.h"
#include "TVirtualFFT.h"

class WienerDecon{
private:
	TVirtualFFT *r2c,*c2r;
	TComplex *smooth,*impulse;
	Double_t *noise;
	Int_t npoints;
	bool SMOOTH,IMPULSE,NOISE;
public:
	WienerDecon(Int_t,TString="");
	~WienerDecon();
	void setSmooth(const Double_t*);
	void setNoiseSPD(const Double_t*);
	void setImpulse(const Double_t*);
	void transform(Double_t*);
};

#endif