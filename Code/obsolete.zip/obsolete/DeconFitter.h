//DeconFitter.h

#ifndef DECONFITTER_H
#define DECONFITTER_H

#include "WienerDecon.h"
#include "RDKTypes.h"

enum DeconFitterMode {kBAPD,kBGO};

class DeconFitter{
private:
	WienerDecon *BGO,*bAPD;
	Double_t *data,E;
	Int_t t,npoints;
public:
	DeconFitter(Int_t=NPOINTS,TString="");
	~DeconFitter();
	void setData(const Double_t*);
	void setData(const Short_t*);
	void setImpulse(DeconFitterMode,Double_t*);
	void setSmooth(Double_t*);
	void setNoise(Double_t*);
	void fit(DeconFitterMode);
	WienerDecon* getFitter(DeconFitterMode);
	inline Double_t *getData(){return data;}
	inline Int_t getT() const {return t;}
	inline Double_t getE() const {return E;}
	static Double_t* generateImpulseBAPD(Int_t N,Double_t C=-1e-3);
	static Double_t* generateImpulseBGO(Int_t N,Double_t C=-1e-3,Double_t D=-1e-3,Int_t T=0);
	static Double_t* generateSmoothing(Int_t N,Double_t sigma=4);
	static Double_t* generateNoiseSPD(Int_t N);
};

#endif