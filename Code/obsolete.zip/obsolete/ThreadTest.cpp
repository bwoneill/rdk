//ThreadTest.cpp

#include "ThreadTest.h"
#include "TString.h"
#include "TRandom1.h"
#include "TStopwatch.h"

#include <iostream>
using namespace std;

ThreadTest::ThreadTest(Int_t n):s1(0),s2(0),N(n),sections(100){
	data=new Double_t[sections];
	for(Int_t i=0;i<sections;i++){
		data[i]=0;
	}
	thread=new TThread*[N];
	for(Int_t i=0;i<N;i++){
		thread[i]=new TThread(Form("core%i",i),(void(*)(void *))&exec,this,TThread::kLowPriority);
		thread[i]->Run();
	}
}

ThreadTest::~ThreadTest(){
	delete[] data;
	delete[] thread;
}

Int_t ThreadTest::getNextSection(){
	Int_t thisSection=-1;
	mutex.Lock();
	if(nextSection<sections){
		thisSection=nextSection++;
	}
	mutex.UnLock();
	return thisSection;
}

void ThreadTest::analyzeSection(Int_t idx){
	TRandom1 rand;
	for(Int_t i=0;i<10000;i++){
		data[idx]+=rand.Rndm();
	}
}

void *ThreadTest::exec(void *arg){
	ThreadTest *data=(ThreadTest*)arg;
	while(true){
		data->s1.Wait();
		Bool_t more;
		Int_t thisSection;
		do{
			thisSection=data->getNextSection();
			more=thisSection>=0;
			if(more){
				data->analyzeSection(thisSection);
			}
		}while(more);
		data->s2.Post();
	}
	return NULL;
}


void ThreadTest::run(){
	TStopwatch stopwatch;
	stopwatch.Start();
	for(Int_t index=0;index<100;index++){
		nextSection=0;
		for(Int_t i=0;i<N;i++){
			s1.Post();
		}
		for(Int_t i=0;i<N;i++){
			s2.Wait();
		}
	}
	stopwatch.Stop();
	cout<<stopwatch.RealTime()<<endl;
}