//ThreadGUI.h

#ifndef THREADGUI_H
#define THERADGUI_H

#include "RQ_OBJECT.h"

class TGMainFrame;
class TGProgressBar;
class TGTextButton;
class TGListBox;

class ThreadGUI{
	RQ_OBJECT("ThreadGUI")
private:
	TGMainFrame *fMain;
	TGProgressBar *fBar;
	TGTextButton *start;
	TGListBox *text;
public:
	ThreadGUI(UInt_t w,UInt_t h);
	~ThreadGUI();
	void doStart();
};

#endif