//Progress.cpp

#include "Progress.h"
#include <iostream>
using namespace std;

Progress::Progress(const Char_t *name,Float_t finish):MAX(finish){
	frame=new TGMainFrame(gClient->GetRoot(),500,500);
	frame->SetWindowName(name);
	p=new TGHProgressBar(frame,TGProgressBar::kFancy,500);
	cout<<"Setting maximum="<<finish<<endl;
	setMax(MAX);
	cout<<"Maximum is "<<p->GetMax()<<endl;
	if(p->GetMax()!=MAX){
		setMax(MAX);
	}
	frame->AddFrame(p);
	start();
}

Progress::~Progress(){
	frame->Destroyed();
	p->Destroyed();
}

void Progress::start(){
	set(0);
	cout<<"Mapping Subwindows"<<endl;
	frame->MapSubwindows();
	cout<<"Resizing"<<endl;
	frame->Resize(p->GetDefaultSize());
	cout<<"Mapping Window"<<endl;
	frame->MapWindow();
}

void Progress::set(Float_t i){
	cout<<"Checking progress bar"<<endl;
	if(p==NULL){
		cout<<"No progress bar"<<endl;
	}else{
		cout<<"Progress bar exists"<<endl;
		cout<<"Checking postion"<<endl;
		cout<<p->GetPosition()<<endl;
		cout<<"Checking maximum"<<endl;
		cout<<p->GetMax()<<endl;
		if(p->GetMax()!=MAX){
			setMax(MAX);
		}
	}
	cout<<"Setting position"<<endl;
	p->SetPosition(i);
	cout<<"Checking if at maximum"<<endl;
	if(i==getMax()){
		cout<<"Closing window"<<endl;
		frame->CloseWindow();
	}
}