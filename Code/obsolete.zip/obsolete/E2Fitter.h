//E2Fitter.h

#ifndef E2FITTER_H
#define E2FITTER_H

#include "EFitter.h"

template<class K> class E2Fitter: public EFitter<K>{
public:
	E2Fitter(Int_t n=NPOINTS):EFitter<K>(n){}
	void fit(const K*);
	inline void next(){this->C+=this->deltaC;this->D+=this->deltaD;}
};

#endif