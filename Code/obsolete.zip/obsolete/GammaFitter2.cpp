//GammaFitter2.cpp

#include "GammaFitter2.h"
#include "TMath.h"
using namespace TMath;
#include "TBenchmark.h"

GammaFitter2::GammaFitter2(Int_t big,Int_t small,Double_t *xaxis){
	full=new E2Fitter2(big);
	limited=new E2Fitter2(small,xaxis);
}

GammaFitter2::~GammaFitter2(){
	delete full;
	delete limited;
}

void GammaFitter2::fit(const Short_t *data){
	Double_t *ddata=new Double_t[full->getN()];
	for(Int_t i=0;i<full->getN();i++){
		ddata[i]=data[i];
	}
	fit(ddata);
	delete[] ddata;
}

void GammaFitter2::fit(const Double_t *data){
	TBenchmark *benchmark;
	if(BENCHMARK){
		benchmark=new TBenchmark();
		benchmark->Start("fitShort");
	}
	Double_t *small=new Double_t[limited->getN()];
	for(Int_t i=0;i<limited->getN();i++){
		small[i]=data[(Int_t)limited->getXaxis(i)];
	}
	limited->resetParameters();
	limited->fit(small);
	if(PRINT && limited->getDebug()){
		limited->getResult()->Print();
	}
	full->setParameters(limited->getParameters());
	full->fit(data);
	if(PRINT && full->getDebug()){
		full->getResult()->Print();
	}
	delete[] small;
	if(BENCHMARK){
		benchmark->Show("fitShort");
		delete benchmark;
	}
}

Double_t GammaFitter2::getE() const{
	Double_t *par=full->getParameters();
	return par[1]*par[3]*Power(par[2]/(par[2]+par[3]),par[2]/par[3])/(par[2]+par[3]);
}

void GammaFitter2::setDebug(Bool_t debug){
	full->setDebug(debug);
	limited->setDebug(debug);
}

Double_t GammaFitter2::getChi2(kType type) const{
	if(type==kFULL){
		return full->getChi2();
	}else if(type==kLIMITED){
		return limited->getChi2();
	}else{
		return -1;
	}
}

Double_t *GammaFitter2::getParameters(kType type) const{
	if(type==kFULL){
		return full->getParameters();
	}else if(type==kLIMITED){
		return limited->getParameters();
	}else{
		return NULL;
	}
}

TFitResultPtr GammaFitter2::getResult(kType type) const{
	if(type=kFULL){
		return full->getResult();
	}else if(type==kLIMITED){
		return limited->getResult();
	}else{
		return NULL;
	}
}

Bool_t GammaFitter2::BENCHMARK=false;
Bool_t GammaFitter2::PRINT=false;