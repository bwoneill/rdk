//LinearFitter.cpp

#include "LinearFitter2.h"

LinearFitter2::LinearFitter2(Int_t size):N(size),X(size),Y(size){
}

LinearFitter2::~LinearFitter2(){
}

void LinearFitter2::setPoint(Int_t i,Double_t x,Double_t y){
	X[i]=x;
	Y[i]=y;
}

void LinearFitter2::fit(){
	Double_t x=0,y=0,xx=0,xy=0,yy=0;
	for(Int_t i=0;i<N;i++){
		x+=X[i];
		y+=Y[i];
		xx+=X[i]*X[i];
		xy+=X[i]*Y[i];
		yy+=Y[i]*Y[i];
	}
	x/=N;
	y/=N;
	xx/=N;
	xy/=N;
	yy/=N;
	m=(xy-x*y)/(xx-x*x);
	b=y-m*x;
	chi2=N*(yy-2*m*xy-2*b*y+m*m*xx+2*m*b*x+b*b);
	R2=1-chi2/N/(yy-y*y);
}