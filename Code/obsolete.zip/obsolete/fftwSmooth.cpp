//fftwSmooth.cpp

#include "fftwSmooth.h"
#include "TMath.h"
using namespace TMath;

fftwSmooth::fftwSmooth(Int_t s,Double_t r,TString flags):npoints(s),radius(r){
	smoother=new TComplex[npoints];
	r2c=TVirtualFFT::FFT(1,&npoints,"R2C K"+flags);
	c2r=TVirtualFFT::FFT(1,&npoints,"C2R K"+flags);
	for(Int_t i=0;i<npoints;i++){
		r2c->SetPoint(i,Gaus(i,0,radius,kTRUE)+Gaus(i,npoints,radius,kTRUE));
	}
	r2c->Transform();
	Double_t re,im;
	for(Int_t i=0;i<npoints;i++){
		r2c->GetPointComplex(i,re,im);
		smoother[i]=TComplex(re,im);
	}
}

fftwSmooth::~fftwSmooth(){
	delete r2c;
	delete c2r;
	delete[] smoother;
}

void fftwSmooth::smooth(Double_t *in){
	for(Int_t i=0;i<npoints;i++){
		r2c->SetPoint(i,in[i]);
	}
	r2c->Transform();
	Double_t re,im;
	for(Int_t i=0;i<npoints;i++){
		r2c->GetPointComplex(i,re,im);
		TComplex tmp(re,im);
		tmp*=smoother[i];
		c2r->SetPointComplex(i,tmp);
	}
	c2r->Transform();
	for(Int_t i=0;i<npoints;i++){
		in[i]=c2r->GetPointReal(i)/npoints;
	}
}