//SmoothFitter.cpp

#include "SmoothFitter.h"

SmoothFitter::SmoothFitter():s4(4,1),s64(32,2),E(0),t(0),xmin(0),xmax(0),t10(0),t90(0){}

void SmoothFitter::fit(const TVectorD& v,Bool_t analyze){
	v1.ResizeTo(v);
	v1=s4.smooth(v);
	v2.ResizeTo(v);
	v2=s64.smooth(v);
	energy();
	if(analyze){
		timing();
		if(t>0){
			Int_t i=t;
			while(i<xmax && t10<t){
				if(v1[i]>getMin()+0.1*E){
					t10=i;
				}else{
					i++;
				}
			}
			while(i<xmax && t90<t){
				if(v1[i]>getMin()+0.9*E){
					t90=i;
				}else{
					i++;
				}
			}
		}
	}
}

void SmoothFitter::energy(){
	xmin=64;
	xmax=xmin;
	for(Int_t i=xmin+1;i<v1.GetNrows();i++){
		if(v2[i]>v2[xmax]){
			xmax=i;
		}else if(v2[i]<v2[xmin]){
			xmin=i;
		}
	}
	E=v2[xmax]-v2[xmin];
}

void SmoothFitter::timing(){
	if(E>THRESHOLD){
		Double_t trig=0.1*E+v2[xmin];
		for(Int_t i=xmax;i>xmin;i--){
			if(v1[i-1]<trig){
				t=i;
				return;
			}
		}
	}
	t=0;
}

Double_t SmoothFitter::THRESHOLD=200;
Double_t SmoothFitter::NOISE=65;