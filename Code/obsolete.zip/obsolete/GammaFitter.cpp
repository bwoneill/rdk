//GammaFitter.cpp

#include "GammaFitter.h"
#include "E2WFitter.h"

#include <iostream>
using namespace std;

GammaFitter::GammaFitter(Int_t n):N(n),lf(n),ef(n){
	init();
	p[2]=C_0;
	p[3]=D_0;
}

GammaFitter::~GammaFitter(){
	clean();
}

void GammaFitter::init(){
	//lf=new LinearFitter<Double_t>(N);
	//ef=new E2WFitter<Double_t>(N);
	data=new Double_t[N];
}

void GammaFitter::clean(){
	//delete lf;
	//delete ef;
	delete data;
}

void GammaFitter::setData(const Double_t *d){
	for(Int_t i=0;i<N;i++){
		data[i]=d[i];
	}
	timing();
}

void GammaFitter::setData(const short *d){
	for(Int_t i=0;i<N;i++){
		data[i]=d[i];
	}
	timing();
}

Int_t GammaFitter::optimize(){
	chi2=1;
	Double_t deltaChi2=1;
	Int_t n=1;
	ef.setParameters(C_0,D_0);
	ef.fit(data);
	while(n<NFIT && deltaChi2>TOLERANCE){
		Double_t temp=0;
		ef.next();
		ef.fit(data);
		temp=(chi2-ef.getChi2())/chi2;
		chi2=ef.getChi2();
		deltaChi2=fabs(temp);
		if(DEBUG){
			cout<<"chi2="<<chi2<<"\tdeltaChi2="<<deltaChi2<<endl;
		}
		n++;
	}
	p[1]=ef.getB();
	p[2]=ef.getC();
	p[3]=ef.getD();
	p[4]=ef.getT();
	return n;
}

void GammaFitter::timing(){
	ef.resetW();
	lf.fit(data);
	xmin=NFLAT-1;
	Double_t h=lf.getMax()-lf.getMin();
	bool weak=h<STRONG,strong=h>1.5*STRONG;
	Double_t avg=lf.getAvg(xmin),sigma=lf.getSigma(xmin);
	if(sigma==0){
		avg=data[xmin];
		for(Int_t i=0;i<N;i++){
			if(data[i]>avg){
				z=i;
				break;
			}
		}
		x=z;
		y=z;
	}else{
		while(xmin+NFLAT<N && lf.getSigma(xmin+NFLAT)<1.2*sigma){
			xmin+=NFLAT;
			avg=lf.getAvg(xmin);
			sigma=lf.getSigma(xmin);
		}
		x=lf.getXmax();
		Double_t target=avg+(1+strong-weak)*sigma;
		for(Int_t i=x;i>xmin-NFLAT;i--){
			if(data[i]<target && data[i-1]<target && !(data[i-2]>target && data[i-3]>target && data[i-4]>target)){
				x=i+1;
				break;
			}
		}
	}
	p[0]=avg;
	p[1]=0;
	p[2]=C_0;
	p[3]=D_0;
	p[4]=x;
	ef.setOffset(getA());
	ef.setTime(getT());
}

const Double_t GammaFitter::C_0=8.8e-4;
const Double_t GammaFitter::D_0=4.5e-3;
Int_t GammaFitter::NFIT=100;
Double_t GammaFitter::TOLERANCE=1e-3;
Double_t GammaFitter::STRONG=1400;
bool GammaFitter::DEBUG=false;