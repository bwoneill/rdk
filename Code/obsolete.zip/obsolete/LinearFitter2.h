//LinearFitter2.h

#ifndef LINEARFITTER2_H
#define LINEARFITTER2_h

#include "Rtypes.h"

#include <vector>

class LinearFitter2{
private:
	std::vector<Double_t> X,Y;
	Double_t m,b,chi2,R2,N;
public:
	LinearFitter2(Int_t);
	~LinearFitter2();
	void setPoint(Int_t,Double_t,Double_t);
	void fit();
	Double_t getM()const{return m;}
	Double_t getB()const{return b;}
	Double_t getChi2()const{return chi2;}
	Double_t getR2()const{return R2;}
};

#endif