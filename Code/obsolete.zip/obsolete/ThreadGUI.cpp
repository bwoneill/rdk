//ThreadGUI.cpp

#include "ThreadGUI.h"
#include "TGClient.h"
#include "TGFrame.h"
#include "TGProgressBar.h"
#include "TGButton.h"
#include "TGListBox.h"

ThreadGUI::ThreadGUI(UInt_t w,UInt_t h){
	fMain=new TGMainFrame(gClient->GetRoot(),w,h);
	TGVerticalFrame *vframe=new TGVerticalFrame(fMain,500,500);
	start=new TGTextButton(vframe,"Start");
	text=new TGListBox(vframe);
	text->SetMultipleSelections();
	fBar=new TGHProgressBar(vframe,TGProgressBar::kFancy);
	start->Connect("Clicked()","ThreadGUI",this,"doStart()");
	vframe->AddFrame(fBar,new TGLayoutHints(kLHintsExpandX,5,5,3,4));
	vframe->AddFrame(text,new TGLayoutHints(kLHintsExpandX | kLHintsExpandY,5,5,3,4));
	vframe->AddFrame(start,new TGLayoutHints(kLHintsCenterX | kLHintsBottom,5,5,3,4));
	fMain->AddFrame(vframe,new TGLayoutHints(kLHintsExpandX | kLHintsExpandY,10,10,10,1));
	fMain->SetWindowName("ThreadGUI test");
	fMain->MapSubwindows();
	fMain->Resize(fMain->GetDefaultSize());
	fMain->Resize(w,h);
	fMain->MapWindow();
}

ThreadGUI::~ThreadGUI(){
	fMain->Cleanup();
	delete fMain;
}

void ThreadGUI::doStart(){
	Int_t p=fBar->GetPosition()+1;
	text->NewEntry(Form("Start button pressed %i times",p));
	fBar->SetPosition(p);
}