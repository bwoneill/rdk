//E2Fitter2.h

#ifndef E2FITTER2_H
#define E2FITTER2_H

#include "EFitter.h"
#include "TGraph.h"
#include "TF1.h"
#include "TFitResult.h"

class E2Fitter2: public EFitter<Double_t>{
private:
	TGraph *graph;
	Double_t *xaxis,*par;
	TF1 *f;
	TFitResultPtr result;
	Int_t status;
	Bool_t debug;
	static Int_t NFITS;
public:
	E2Fitter2(Int_t=NPOINTS,Double_t* = 0);
	~E2Fitter2();
	void fit(const Double_t*);
	inline void next(){};
	inline TF1 *getF(){return f;}
	inline Int_t getStatus() const {return status;}
	inline TFitResultPtr getResult() const {return result;}
	inline static Int_t getNE2fits(){return NFITS;}
	inline void setDebug(Bool_t d){debug=d;}
	inline Bool_t getDebug() const {return debug;}
	inline Double_t* getParameters() const {return par;}
	void setParameters(Double_t*);
	inline Double_t getXaxis(Int_t i) const {return xaxis[i];}
	void resetParameters();
};

#endif