//DeconFitter.cpp

#include "DeconFitter.h"
#include "TMath.h"
using namespace TMath;

DeconFitter::DeconFitter(Int_t n,TString option):npoints(n){
	BGO=new WienerDecon(npoints,option);
	bAPD=new WienerDecon(npoints,option);
	data=new Double_t[npoints];
	Double_t *impulseBAPD=generateImpulseBAPD(npoints),
		*impulseBGO=generateImpulseBGO(npoints),
		*smooth=generateSmoothing(npoints),
		*noise=generateNoiseSPD(npoints);
	bAPD->setImpulse(impulseBAPD);
	bAPD->setSmooth(smooth);
	bAPD->setNoiseSPD(noise);
	BGO->setImpulse(impulseBGO);
	BGO->setSmooth(smooth);
	BGO->setNoiseSPD(noise);
	delete[] impulseBAPD;
	delete[] impulseBGO;
	delete[] smooth;
	delete[] noise;
}

DeconFitter::~DeconFitter(){
	delete bAPD;
	delete BGO;
	delete[] data;
}

void DeconFitter::setData(const Double_t *d){
	for(Int_t i=0;i<npoints;i++){
		data[i]=d[i];
	}
}

void DeconFitter::setData(const Short_t *d){
	for(Int_t i=0;i<npoints;i++){
		data[i]=d[i];
	}
}

void DeconFitter::fit(DeconFitterMode mode){
	if(mode==kBAPD){
		bAPD->transform(data);
	}else if(mode==kBGO){
		BGO->transform(data);
	}
	t=npoints/32;
	Double_t max=data[t];
	for(Int_t i=t;i<npoints*15/16;i++){
		if(data[i]>max){
			max=data[i];
			t=i;
		}
	}
	E=max;
}

Double_t* DeconFitter::generateImpulseBAPD(Int_t N,Double_t C){
	Double_t *impulse=new Double_t[N];
	for(Int_t i=0;i<N;i++){
		impulse[i]=Exp(C*i);
	}
	return impulse;
}

Double_t* DeconFitter::generateImpulseBGO(Int_t N,Double_t C,Double_t D,Int_t T){
	Double_t *impulse=new Double_t[N];
	for(Int_t i=0;i<N;i++){
		if(i<T){
			impulse[i]=0;
		}else{
			impulse[i]=Exp(C*(i-T))*(1-Exp(D*(i-T)));
		}
	}
	return impulse;
}

Double_t* DeconFitter::generateSmoothing(Int_t N,Double_t sigma){
	Double_t *smooth=new Double_t[N];
	for(Int_t i=0;i<N;i++){
		smooth[i]=Gaus(i,0,sigma,kTRUE)+Gaus(i,N,sigma,kTRUE);
	}
	return smooth;
}

Double_t* DeconFitter::generateNoiseSPD(Int_t N){
	Double_t *noise=new Double_t[N];
	for(Int_t i=0;i<N;i++){
		noise[i]=Exp(8.73953+3.15517e-42*Power(i-N/2,14));
	}
	return noise;
}

WienerDecon* DeconFitter::getFitter(DeconFitterMode mode){
	if(mode==kBGO){
		return BGO;
	}else if(mode==kBAPD){
		return bAPD;
	}else{
		return NULL;
	}
}

void DeconFitter::setImpulse(DeconFitterMode mode,Double_t *impulse){
	if(mode==kBGO){
		BGO->setImpulse(impulse);
	}else if(mode==kBAPD){
		bAPD->setImpulse(impulse);
	}
}

void DeconFitter::setSmooth(Double_t *smooth){
	BGO->setImpulse(smooth);
	bAPD->setImpulse(smooth);
}

void DeconFitter::setNoise(Double_t *noise){
	BGO->setImpulse(noise);
	bAPD->setImpulse(noise);
}