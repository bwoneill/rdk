//DataAnalyzer.cpp

#include "DataAnalyzer.h"

#include "TSemaphore.h"

DataAnalyzer::DataAnalyzer(RawData *rdata,Recon *recon){
	this->data=rdata;
	this->recon=recon;
}