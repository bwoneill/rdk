//bgoPlotter.h

#ifndef BGOPLOTTER_H
#define BGOPLOTTER_H

#include "RDKTypes.h"
#include "TreeReader.h"
#include "CalibrationList.h"
#include "TH1F.h"
#include <vector>

class TString;
class TCanvas;

class bgoPlotter{
private:
	TCanvas *canvas;
	TreeReader reader;
	CalibrationList list;
	std::vector<TH1F*> delta_t_bgo,on_peak_bgo,off_peak_bgo,bgc_bgo;
	static const Int_t delta_t_min,delta_t_max,t_min,t_max;
	static const Int_t t_bg_min,t_bg_max,delta_t_p;
	static const Double_t max,min,bin_size;
	Long64_t ep;
	TString formTitle(Int_t)const;
	Int_t getChannel(Int_t)const;
public:
	bgoPlotter();
	~bgoPlotter();
	void plot();
	void drawDelta_t(Int_t);
	void drawOnPeak(Int_t);
	void drawOffPeak(Int_t);
	void drawBGC(Int_t);
	Int_t getEvent(const Recon&);
	void save();
};

#endif