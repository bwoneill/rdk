//Shaper.h

#ifndef SHAPER_H
#define SHAPER_H

#include "TF1.h"
#include "TVector.h"

class Shaper{
private:
	TF1 *pulse;
	Int_t dim;
	TVectorD real,imag;
public:
	Shaper(TF1*,Int_t);
	void setPulse(TF1*,Int_t);
	TVectorD shape(const TVectorD&,bool=true);
};

#endif