//GammaAnalyzer.cpp

#include "GammaAnalyzer.h"
#include "Smoother.h"

#include "TSemaphore.h"
#include "TThread.h"
#include "TMath.h"
using namespace TMath;

GammaAnalyzer::GammaAnalyzer(RawData *rdata,Recon *recon,Int_t N):
                             DataAnalyzer(rdata,recon),y(2048),y1(2048),y2(2048),n(N){
	smoother=new Smoother(4,1);
	eSmoother=new Smoother(32,2);
}

GammaAnalyzer::~GammaAnalyzer(){
	delete smoother;
	delete eSmoother;
}

void GammaAnalyzer::analyze(Int_t N){
	const Short_t *sig=data->ch[n];
	Double_t max=sig[0],min=max,sum0=0,sum1=0,sum2=0;
	Int_t xmax=0,xmin=0;
	for(Int_t i=0;i<2048;i++){
		y[i]=sig[i];
		if(y[i]>max){
			max=y[i];
			xmax=i;
		}else if(y[i]<min){
			min=y[i];
			xmin=i;
		}
		sum0+=y[i];
		sum1+=i*y[i];
		sum2+=y[i]*y[i];
		if(i>2){
			Double_t sigma2=sum2/(i+1)-sum0*sum0/(i+1)/(i+1);
			m[i]=(12*sum1-6*i*sum0)/(i*(i+1.0)*(i+2.0));
			b[i]=((4*i+2)*sum0-6*sum1)/((i+1.0)*(i+2.0));
			sigma[i]=Sqrt(sigma2);
			//chi2[i]=sum2-(12*sum1*sum1-12*i*sum0*sum1+i*(4.0*i+2)*sum0*sum0)/(i*(i+1.0)*(i+2.0));
			//R2[i]=1-chi2[i]/(sigma2*(i+1));
			//sigmab[i]=Sqrt(chi2[i]*(4*i+2)/((i-1.0)*(i+1.0)*(i+2.0)));
			//sigmam[i]=Sqrt(chi2[i]*12/((i-1.0)*i*(i+1.0)*(i+2.0)));
			//sigmaAvg[i]=Sqrt(sigmab[i]*sigmab[i]+sigmam[i]*sigmam[i]*i*i/4);
		}else{
			m[i]=0;
			b[i]=0;
			sigma[i]=0;
			//chi2[i]=0;
			//R2[i]=0;
			//sigmab[i]=0;
			//sigmam[i]=0;
			//sigmaAvg[i]=0;
		}
	}
	if(xmax<=0){
		xmax=1;
	}else if(xmax>=2047){
		xmax=2046;
	}
	if(xmin<=0){
		xmin=1;
	}else if(xmin>=2047){
		xmin=2046;
	}
	Double_t jump=Max(y[xmax]-(y[xmax+1]+y[xmax-1])/2.,(y[xmin-1]+y[xmin+1])/2.-y[xmin]);
	//Double_t jump=y[xmax]-(y[xmax+1]+y[xmax-1])/2.;
	if(max<MAXHEIGHT && jump<200 && xmax>xmin && xmax>128 && xmax<896 && max-min>300){
		smoother->smooth(y,y1);
		eSmoother->smooth(y,y2);
		max=y2[0];
		xmax=0;
		min=y2[0];
		xmin=0;
		for(Int_t i=0;i<2048;i++){
			if(y2[i]>max){
				max=y2[i];
				xmax=i;
			}else if(y2[i]<min){
				min=y2[i];
				xmin=i;
			}
		}
		Double_t t_gamma=0,E_gamma=0;
		for(Int_t i=xmax;i>64 && t_gamma==0;i--){
			Int_t j=i-32;
			Double_t E=max-b[j]-m[j]*xmax,th=0.1*E+b[j]+m[j]*i;
			if(y1[i]<th){
				t_gamma=i+1;
				E_gamma=E;
			}
		}
		recon[N].t_gamma[n]=t_gamma;
		recon[N].E_gamma[n]=E_gamma;
		recon[N].chi2_gamma[n]=0;
		recon[N].R2_gamma[n]=0;
		for(Int_t i=0;i<5;i++){
			recon[N].fitparam[n][i]=0;
		}
		recon[N].nfit[n]=-1;
		recon[N].noise[n]=0;
		recon[N].t_rise[n]=xmax-t_gamma;
	}else{
		recon[N].E_gamma[n]=0;
		recon[N].t_gamma[n]=0;
		recon[N].chi2_gamma[n]=0;
		recon[N].R2_gamma[n]=0;
		for(Int_t i=0;i<5;i++){
			recon[N].fitparam[n][i]=0;
		}
		recon[N].nfit[n]=-1;
		recon[N].noise[n]=0;
		recon[N].t_rise[n]=0;
	}
}