//E2Fitter.cpp

#include "E2Fitter.h"

#include <cmath>

template<class K> void E2Fitter<K>::fit(const K *data){
	const Double_t F=this->C+this->D;
	Double_t sum_y=0,sum_y2=0,sum_z2=0,sum_zy=0;
	Double_t alpha_11=0,alpha_12=0,alpha_22=0;
	Double_t gamma_1y=0,gamma_2y=0,gamma_1z=0,gamma_2z=0;
	for(Int_t i=0;i<this->N-this->T;i++){
		Double_t y=data[i+(Int_t)this->T]-this->A,eCi=exp(-this->C*i),eDi=exp(-this->D*i)
			,eFi=exp(-F*i),z=eCi*(1-eDi),a=exp(-F*i);
		Double_t dzdC=-i*z,dzdD=i*a,dzdT=this->C*eCi-F*eFi;
		sum_y+=y;
		sum_y2+=y*y;
		sum_z2+=z*z;
		sum_zy+=z*y;
		alpha_11+=i*i*exp(-2*this->C*i);
		alpha_12+=i*i*exp(-(this->C+F)*i);
		alpha_22+=i*i*exp(-2*F*i);
		gamma_1y+=i*y*eCi;
		gamma_2y+=i*y*eFi;
		gamma_1z+=i*z*eCi;
		gamma_2z+=i*z*eFi;
	}
	this->B=sum_zy/sum_z2;
	this->chi2=sum_y2-sum_zy*sum_zy/sum_z2;
	this->R2=1-this->chi2/(sum_y2-sum_y*sum_y/(this->N-this->T));
	Double_t det=alpha_11*alpha_22-alpha_12*alpha_12;
	this->deltaC=(alpha_12*(gamma_2y-this->B*gamma_2z)-alpha_22*(gamma_1y-this->B*gamma_1z))/this->B/det;
	this->deltaD=((alpha_11-alpha_12)*(gamma_2y-this->B*gamma_2z)-(alpha_12-alpha_22)*(gamma_1y-this->B*gamma_1z))/this->B/det;
	this->deltaT=0;
}

template class E2Fitter<Short_t>;
template class E2Fitter<Int_t>;
template class E2Fitter<Float_t>;
template class E2Fitter<Double_t>;