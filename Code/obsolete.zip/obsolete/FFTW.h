//FFTW.h

#ifndef FFTW_H
#define FFTW_H

#include "TString.h"

class FFTW{
private:
public:
	static void exportWisdom(TString);
	static void importWisdom(TString);
	static void forgetWisdom();
};

#endif