//EpAnalyzer.cpp

#include "EpAnalyzer.h"

#include "TThread.h"
#include "TSemaphore.h"

EpAnalyzer::EpAnalyzer(RawData *rdata,Recon *recon)
		:DataAnalyzer(rdata,recon){
}

EpAnalyzer::~EpAnalyzer(){
}

void EpAnalyzer::analyze(Int_t N){
	const Short_t *sig=data->ch[15];
	Int_t t_e=0;
	Double_t E_e=sig[0];
	for(Int_t i=0;i<896;i++){
		if(sig[i]>E_e){
			E_e=sig[i];
			t_e=i;
		}
	}
	Double_t avg=0;
	Int_t start=0,stop=t_e-128;
	for(Int_t i=start;i<stop;i++){
		avg+=sig[i];
	}
	start=t_e+128;
	stop=t_e+896;
	for(Int_t i=start;i<stop;i++){
		avg+=sig[i];
	}
	avg/=(t_e+640);
	Int_t t_p=t_e+30;
	Double_t E_p=sig[t_p];
	Bool_t descend=kTRUE;
	for(Int_t i=t_p;i<stop;i++){
		if(descend && i<2043){
			descend=kFALSE;
			for(Int_t j=1;j<5;j++){
				descend|=sig[i]>sig[i+j];
			}
			E_p=sig[i];
			t_p=i;
		}else if(sig[i]>E_p){
			E_p=sig[i];
			t_p=i;
		}
	}
	recon[N].E_e=E_e-avg;
	recon[N].t_e=t_e;
	recon[N].E_p=E_p-avg;
	recon[N].t_p=t_p;
}