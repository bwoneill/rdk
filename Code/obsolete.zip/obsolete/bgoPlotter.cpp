//bgoPlotter.cpp

#include "bgoPlotter.h"

#include <iostream>

#include "RDKTypes.h"
#include "TCanvas.h"
#include "TChain.h"

using namespace std;

bgoPlotter::bgoPlotter():list(Form("%s/calibration/TCfit_511keV_calibration_21Feb11.dat",RDKANAL)){
	Double_t bins=max/bin_size;
	for(Int_t i=0;i<12;i++){
		TString temp=formTitle(i);
		TString name,title;
		name.Form("on_peak_bgo_%s",temp.Data());
		title.Form("On peak BGO %s;keV",temp.Data());
		on_peak_bgo.push_back(new TH1F(name,title,bins,0,max));
		on_peak_bgo[i]->Sumw2();
		name.Form("off_peak_bgo_%s",temp.Data());
		title.Form("Off peak BGO %s;keV",temp.Data());
		off_peak_bgo.push_back(new TH1F(name,title,bins,0,max));
		off_peak_bgo[i]->Sumw2();
		name.Form("bgc_bgo_%s",temp.Data());
		title.Form("Background corrected BGO %s;keV",temp.Data());
		bgc_bgo.push_back(new TH1F(name,title,bins,0,max));
		bgc_bgo[i]->Sumw2();
		name.Form("delta_t_bgo_%s",temp.Data());
		title.Form("BGO %s;#Delta_{t} (#mus)",temp.Data());
		delta_t_bgo.push_back(new TH1F(name,title,NPOINTS*3/4,
			-NPOINTS/4*0.04-0.02,NPOINTS/2*0.04-0.02));
	}
	canvas=new TCanvas("canvas");
	//on_peak_bgo.push_back(new TH1F("on_peak_bgo_sum","On peak BGO sum;keV",bins,0,max));
	//on_peak_bgo[11]->Sumw2();
	//off_peak_bgo.push_back(new TH1F("off_peak_bgo_sum","Off peak BGO sum;keV",bins,0,max));
	//off_peak_bgo[11]->Sumw2();
	//bgc_bgo.push_back(new TH1F("bgc_bgo_sum","Background corrected BGO sum;keV",bins,0,max));
	//bgc_bgo[11]->Sumw2();
	//delta_t_bgo.push_back(new TH1F("delta_t_bgo_sum","BGO sum;#Delta_{t} (#mus)",NPOINTS*3/4,
	//		-NPOINTS/4*0.04-0.02,NPOINTS/2*0.04-0.02));
}

bgoPlotter::~bgoPlotter(){
}

TString bgoPlotter::formTitle(Int_t i)const{
	TString result="";
	if(i==11){
		result="sum";
	}else{
		Int_t ch=getChannel(i);
		result.Form("%i%i",ch/7,ch%7);
	}
	return result;
}

void bgoPlotter::plot(){
	for(Int_t i=0;i<11;i++){
		on_peak_bgo[i]->Reset("M");
		off_peak_bgo[i]->Reset("M");
		bgc_bgo[i]->Reset("M");
		delta_t_bgo[i]->Reset("M");
	}
	reader.openList(Form("%s/runlist.csv",RDKANAL));
	ep=0;
	for(Long64_t i=0;i<reader.tree->GetEntries();i++){
		reader.tree->GetEntry(i);
		Double_t t_p=reader.recon.t_p;
		Double_t t_e=reader.recon.t_e;
		if(t_p-t_e<delta_t_p){
			ep++;
			reader.recon=list.calibrate(reader.entry,reader.recon);
			Int_t index=-1;
			for(Int_t j=0;j<11;j++){
				Int_t ch=getChannel(j);
				Double_t t_gamma=reader.recon.t_gamma[ch];
				Double_t E_gamma=reader.recon.E_gamma[ch];
				if(t_gamma>0 && t_gamma<NPOINTS && E_gamma>min && E_gamma<max){
					if(index!=-1){
						index=-1;
						j=12;
					}else{
						index=j;
					}
				}
			}
			if(index!=-1){
				Int_t ch=getChannel(index);
				Double_t delta_t=reader.recon.t_gamma[ch]-t_e;
				Double_t E_gamma=reader.recon.E_gamma[ch];
				delta_t_bgo[index]->Fill(delta_t*0.04);
				if(delta_t>t_min && delta_t<=t_max){
					on_peak_bgo[index]->Fill(E_gamma);
				}else if(delta_t>t_bg_min && delta_t<=t_bg_max){
					off_peak_bgo[index]->Fill(E_gamma);
				}
			}
		}
	}
	Double_t scale=double(t_min-t_max)/double(t_bg_max-t_bg_min-t_max+t_min);
	for(Int_t i=0;i<11;i++){
		delta_t_bgo[11]->Add(delta_t_bgo[i]);
		bgc_bgo[i]->Add(on_peak_bgo[i],off_peak_bgo[i],1,scale);
		on_peak_bgo[11]->Add(on_peak_bgo[i]);
		off_peak_bgo[11]->Add(off_peak_bgo[i]);
		bgc_bgo[11]->Add(bgc_bgo[i]);
	}
}

Int_t bgoPlotter::getChannel(Int_t i)const{
	if(i>=6){
		i+=2;
	}else if(i>=2){
		i+=1;
	}
	return i;
}

void bgoPlotter::drawDelta_t(Int_t i){
	if(i>=0 && i<delta_t_bgo.size()){
		delta_t_bgo[i]->Draw();
	}
}

void bgoPlotter::drawOnPeak(Int_t i){
	if(i>=0 && i<on_peak_bgo.size()){
		on_peak_bgo[i]->Draw();
	}
}

void bgoPlotter::drawOffPeak(Int_t i){
	if(i>=0 && i<off_peak_bgo.size()){
		off_peak_bgo[i]->Draw();
	}
}

void bgoPlotter::drawBGC(Int_t i){
	if(i>=0 && i<bgc_bgo.size()){
		bgc_bgo[i]->Draw();
	}
}

Int_t bgoPlotter::getEvent(const Recon &recon){			
	Int_t index=-1;
	for(Int_t j=0;j<11;j++){
		Int_t ch=getChannel(j);
		Double_t t_gamma=reader.recon.t_gamma[ch];
		Double_t E_gamma=reader.recon.E_gamma[ch];
		if(t_gamma>0 && t_gamma<NPOINTS && E_gamma>min && E_gamma<max){
			if(index!=-1){
				index=-1;
				j=12;
			}else{
				index=j;
			}
		}
	}
	return index;
}

void bgoPlotter::save(){
	for(Int_t i=0;i<delta_t_bgo.size();i++){
		delta_t_bgo[i]->Draw();
		canvas->SaveAs(Form("%s/Temp/bgo/%s.png",RDKHOME,delta_t_bgo[i]->GetName()));
		on_peak_bgo[i]->Draw();
		canvas->SaveAs(Form("%s/Temp/bgo/%s.png",RDKHOME,on_peak_bgo[i]->GetName()));
		off_peak_bgo[i]->Draw();
		canvas->SaveAs(Form("%s/Temp/bgo/%s.png",RDKHOME,off_peak_bgo[i]->GetName()));
		bgc_bgo[i]->Draw();
		canvas->SaveAs(Form("%s/Temp/bgo/%s.png",RDKHOME,bgc_bgo[i]->GetName()));
	}
}

const Int_t bgoPlotter::delta_t_min=-50;
const Int_t bgoPlotter::delta_t_max=50;
const Int_t bgoPlotter::t_min=-50;
const Int_t bgoPlotter::t_max=50;
const Int_t bgoPlotter::t_bg_min=-250;
const Int_t bgoPlotter::t_bg_max=550;
const Int_t bgoPlotter::delta_t_p=650;
const Double_t bgoPlotter::max=950;
const Double_t bgoPlotter::min=9.5;
const Double_t bgoPlotter::bin_size=5;