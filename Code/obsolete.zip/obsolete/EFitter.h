//EFitter.h

#ifndef EFITTER_H
#define EFITTER_H

#include "RDKTypes.h"

#include <cmath>

template<class K> class EFitter{
protected:
	Double_t A,B,C,D,chi2,R2;
	Double_t deltaC,deltaD,deltaT;
	Double_t T;
	const Int_t N;
public:
	EFitter(Int_t n=NPOINTS):A(0),C(0),D(0),N(n),R2(0),chi2(0),deltaC(0),deltaD(0),deltaT(0){}
	virtual void fit(const K*)=0;
	inline void setOffset(Double_t a){A=a;}
	inline void setTime(Double_t t){T=t;}
	inline void setParameters(Double_t c,Double_t d){C=c;D=d;}
	inline Double_t getA() const {return A;}
	inline Double_t getB() const {return B;}
	inline Double_t getC() const {return C;}
	inline Double_t getD() const {return D;}
	inline Double_t getT() const {return T;}
	inline Double_t getR2() const {return R2;}
	inline Double_t getChi2() const {return chi2;}
	inline Double_t getNoise() const {return sqrt(chi2/(N-T));}
	inline Double_t getDeltaC() const {return deltaC;}
	inline Double_t getDeltaD() const {return deltaD;}
	inline Double_t getDeltaT() const {return deltaT;}
	inline Double_t getN() const {return N;}
	virtual void next()=0;
};

#endif