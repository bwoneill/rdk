//SmoothFitter.h

#ifndef SMOOTHFITTER_H
#define SMOOTHFITTER_H

#include "RDKTypes.h"
#include "Smoother.h"

class SmoothFitter{
private:
	TVectorD v1,v2;
	Smoother s4,s64;
	Double_t E,t,xmin,xmax,t10,t90;
	void energy();
	void timing();
public:
	SmoothFitter();
	void fit(const TVectorD&,Bool_t=kTRUE);
	inline Double_t getEnergy() const {return E;}
	inline Double_t getMax() const {return v2[xmax];}
	inline Double_t getMin() const {return v2[xmin];}
	inline Double_t getT() const {return t;}
	inline Double_t getT10() const {return t10;}
	inline Double_t getT90() const {return t90;}
	inline Double_t getXmax() const {return xmax;}
	inline TVectorD getV4() const {return v1;}
	inline TVectorD getV64() const {return v2;}
	static Double_t THRESHOLD,NOISE;
};

#endif