//HaarWavelet.cpp

#include "HaarWavelet.h"

#include <cmath>
#include <iostream>

using namespace std;

const double INV_SQRT_2=1.0/sqrt(2.0);

HaarWavelet::HaarWavelet(unsigned int log2length){
	this->log2length=log2length;
	length=1<<log2length;
	temp.resize(length);
	buff.resize(length);
}

HaarWavelet::~HaarWavelet(){
}

void HaarWavelet::full_dwt(const vector<double> &in,vector<double> &out){
	unsigned int half_length=length>>1;
	for(unsigned int i=0;i<half_length;i++){
		double data0=in[2*i],data1=in[2*i+1];
		temp[i]=(data0+data1)*INV_SQRT_2;
		//out[i]=(data0+data1)*INV_SQRT_2;
		out[half_length+i]=(data0-data1)*INV_SQRT_2;
	}
	while(half_length>1){
		half_length>>=1;
		for(unsigned int i=0;i<half_length;i++){
			double data0=temp[2*i],data1=temp[2*i+1];
			temp[i]=(data0+data1)*INV_SQRT_2;
			out[half_length+i]=(data0-data1)*INV_SQRT_2;
		}
	}
	out[0]=temp[0];
}

void HaarWavelet::full_idwt(const vector<double> &in,vector<double> &out){
	unsigned int half_length=1,full_half_length=length>>1;
	temp[0]=in[0];
	while(half_length<full_half_length){
		buff.assign(temp.begin(),temp.begin()+half_length);
		for(unsigned int i=0;i<half_length;i++){
			double data0=buff[i],data1=in[i+half_length];
			temp[2*i]=(data0+data1)*INV_SQRT_2;
			temp[2*i+1]=(data0-data1)*INV_SQRT_2;
		}
		half_length<<=1;
	}
	for(unsigned int i=0;i<full_half_length;i++){
		double data0=temp[i],data1=in[i+full_half_length];
		//double data0=in[i],data1=in[i+full_half_length];
		out[2*i]=(data0+data1)*INV_SQRT_2;
		out[2*i+1]=(data0-data1)*INV_SQRT_2;
	}
}