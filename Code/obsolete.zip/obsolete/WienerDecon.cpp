//WienerDecon.cpp

#include "WienerDecon.h"
#include "RDKTypes.h"

#include "TComplex.h"
#include "TMath.h"
using namespace TMath;

#include <fstream>
using namespace std;

WienerDecon::WienerDecon(Int_t n,TString flags):npoints(n){
	SMOOTH=false;
	IMPULSE=false;
	NOISE=false;
	smooth=new TComplex[npoints];
	impulse=new TComplex[npoints];
	noise=new Double_t[npoints];
	r2c=TVirtualFFT::FFT(1,&npoints,"R2C K"+flags);
	c2r=TVirtualFFT::FFT(1,&npoints,"C2R K"+flags);
}

WienerDecon::~WienerDecon(){
	delete r2c;
	delete c2r;
	delete smooth;
	delete impulse;
	delete noise;
}

void WienerDecon::setSmooth(const Double_t *S){
	for(Int_t i=0;i<npoints;i++){
		r2c->SetPoint(i,S[i]);
	}
	r2c->Transform();
	for(Int_t i=0;i<npoints;i++){
		Double_t re,im;
		r2c->GetPointComplex(i,re,im);
		smooth[i]=TComplex(re,im);
	}
	SMOOTH=true;
}

void WienerDecon::setNoiseSPD(const Double_t *N){
	for(Int_t i=0;i<npoints;i++){
		noise[i]=N[i];
	}
	NOISE=true;
}

void WienerDecon::setImpulse(const Double_t *I){
	for(Int_t i=0;i<npoints;i++){
		r2c->SetPoint(i,I[i]);
	}
	r2c->Transform();
	for(Int_t i=0;i<npoints;i++){
		Double_t re,im;
		r2c->GetPointComplex(i,re,im);
		impulse[i]=TComplex(re,im);
	}
	IMPULSE=true;
}

void WienerDecon::transform(Double_t *in){
	if(!IMPULSE){
		throw RDKException("no impulse response function set");
	}
	for(Int_t i=0;i<npoints;i++){
		r2c->SetPoint(i,in[i]);
	}
	r2c->Transform();
	for(Int_t i=0;i<npoints;i++){
		Double_t re,im;
		r2c->GetPointComplex(i,re,im);
		TComplex o(re,im);
		o/=impulse[i];
		if(NOISE){
			o/=1+noise[i]/o.Rho2();
		}
		if(SMOOTH){
			o*=smooth[i];
		}
		c2r->SetPoint(i,o.Re(),o.Im());
	}
	c2r->Transform();
	for(Int_t i=0;i<npoints;i++){
		in[i]=c2r->GetPointReal(i);
	}
}