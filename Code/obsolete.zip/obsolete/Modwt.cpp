//Modwt.cpp

#include "Modwt.h"
#include <cmath>

using namespace std;

Modwt::Modwt(unsigned int l){
	length=l;
	depth=0;
	while(l>1){
		depth++;
		l>>=1;
	}
	v.resize(length*(depth+1));
	w.resize(length*(depth+1));
	d.resize(length*(depth+1));
	s.resize(length*(depth+1));
	zero.assign(length*(depth+1),0);
}

Modwt::Modwt(unsigned int l,const vector<double> &wavelet){
	length=l;
	depth=0;
	while(l>1){
		depth++;
		l>>=1;
	}
	v.resize(length*(depth+1));
	w.resize(length*(depth+1));
	d.resize(length*(depth+1));
	s.resize(length*(depth+1));
	zero.assign(length*(depth+1),0);
	setWavelet(wavelet);
}

Modwt::~Modwt(){
}

void Modwt::setWavelet(const vector<double> &wavelet){	h=wavelet;
	L=h.size();
	double weight=0;
	for(int i=0;i<L;i++){
		weight+=h[i]*h[i];
	}
	weight=1.0/sqrt(2*weight);
	g.resize(L);
	for(int i=0;i<L;i++){
		h[L-1-i]*=weight;
		if(i%2){
			g[i]=h[L-1-i];
		}else{
			g[i]=-h[L-1-i];
		}
	}
}

void Modwt::transform(const vector<double> &in){
	for(int i=0;i<length;i++){
		v[i]=in[i];
		w[i]=0;
	}
	for(unsigned int j=1;j<depth;j++){
		downstep(j,v,v,w);
		//for(unsigned int t=0;t<length;t++){
		//	int k=t;
		//	double temp_w=h[0]*v[(j-1)*length+t];
		//	double temp_v=g[0]*v[(j-1)*length+t];
		//	for(unsigned int n=1;n<L;n++){
		//		k-=(1<<j-1);
		//		while(k<0){
		//			k+=length;
		//		}
		//		temp_w+=h[n]*v[(j-1)*length+k];
		//		temp_v+=g[n]*v[(j-1)*length+k];
		//	}
		//	w[j*length+t]=temp_w;
		//	v[j*length+t]=temp_v;
		//}
	}
}

void Modwt::itransform(vector<double> &out){
	for(unsigned int j=depth-1;j>0;j--){
		upstep(j,v,v,w);
		//for(unsigned int t=0;t<length;t++){
		//	int k=t;
		//	double temp_v=h[0]*w[j*length+t]+g[0]*v[j*length+t];
		//	for(unsigned int n=1;n<L;n++){
		//		k+=(1<<j-1);
		//		k%=length;
		//		temp_v+=h[n]*w[j*length+k]+g[n]*v[j*length+k];
		//	}
		//	v[(j-1)*length+t]=temp_v;
		//}
	}
	for(int i=0;i<length;i++){
		out[i]=v[i];
	}
}

void Modwt::downstep(unsigned int j,const std::vector<double> &v_in,std::vector<double> &v_out,std::vector<double> &w_out){
	for(unsigned int t=0;t<length;t++){
		int k=t;
		double temp_w=h[0]*v_in[(j-1)*length+t];
		double temp_v=g[0]*v_in[(j-1)*length+t];
		for(unsigned int n=1;n<L;n++){
			k-=(1<<j-1);
			while(k<0){
				k+=length;
			}
			temp_w+=h[n]*v_in[(j-1)*length+k];
			temp_v+=g[n]*v_in[(j-1)*length+k];
		}
		w_out[j*length+t]=temp_w;
		v_out[j*length+t]=temp_v;
	}
}

void Modwt::upstep(unsigned int j,const std::vector<double> &v_in,const std::vector<double> &w_in,std::vector<double> &v_out){
	for(unsigned int t=0;t<length;t++){
		int k=t;
		double temp_v=h[0]*w_in[j*length+t]+g[0]*v_in[j*length+t];
		for(unsigned int n=1;n<L;n++){
			k+=(1<<j-1);
			k%=length;
			temp_v+=h[n]*w_in[j*length+k]+g[n]*v_in[j*length+k];
		}
		v_out[(j-1)*length+t]=temp_v;
	}
}