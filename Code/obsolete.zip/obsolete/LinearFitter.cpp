//LinearFitter.cpp

#include "LinearFitter.h"

#include <cmath>

template<class T> LinearFitter<T>::LinearFitter(Int_t N):n(N){
	R2=new Double_t[n];
	m=new Double_t[n];
	b=new Double_t[n];
	sigma=new Double_t[n];
	chi2=new Double_t[n];
	sigmab=new Double_t[n];
	sigmam=new Double_t[n];
	sigmaAvg=new Double_t[n];
}

template<class T> LinearFitter<T>::~LinearFitter(){
	delete[] R2;
	delete[] m;
	delete[] b;
	delete[] sigma;
	delete[] chi2;
	delete[] sigmab;
	delete[] sigmam;
	delete[] sigmaAvg;
}

template<class T> void LinearFitter<T>::fit(const T *data){
	//Double_t rho2=0,rho1=0,rho0=0;
	Double_t sum1=0,sum0=0,sum2=0;
	min=data[0];
	max=min;
	xmax=0;
	xmin=0;
	for(Int_t i=0;i<n;i++){
		Double_t y=data[i];
		if(y>max){
			max=y;
			xmax=i;
		}else if(y<min){
			min=y;
			xmin=i;
		}
		//rho0+=y*(2*sum0+y);
		//rho1+=2*y*(i*sum0+sum1+i*y);
		//rho2+=i*y*(2*sum1+i*y);
		sum0+=y;
		sum1+=i*y;
		sum2+=y*y;
		if(i>2){
			Double_t sigma2=sum2/(i+1)-pow(sum0/(i+1),2);
			//R2[i]=(12*rho2-6*i*rho1+3*rho0*i*i)/(sigma2*i*(i+1)*(i+1)*(i+2));
			m[i]=(12*sum1-6*i*sum0)/(i*(i+1.0)*(i+2.0));
			b[i]=((4*i+2)*sum0-6*sum1)/((i+1.0)*(i+2.0));
			sigma[i]=sqrt(sigma2);
			//chi2[i]=sum2-(12*rho2-6*i*rho1+i*(4*i+2))/(i*(i+1.0)*(i+2.0));
			chi2[i]=sum2-(12*sum1*sum1-12*i*sum0*sum1+i*(4.0*i+2)*sum0*sum0)/(i*(i+1.0)*(i+2.0));
			R2[i]=1-chi2[i]/(sigma2*(i+1));
			sigmab[i]=sqrt(chi2[i]*(4*i+2)/((i-1.0)*(i+1.0)*(i+2.0)));
			sigmam[i]=sqrt(chi2[i]*12/((i-1.0)*i*(i+1.0)*(i+2.0)));
			sigmaAvg[i]=sqrt(sigmab[i]*sigmab[i]+sigmam[i]*sigmam[i]*i*i/4);
		}else{
			chi2[i]=0;
			R2[i]=0;
			m[i]=0;
			b[i]=0;
			sigma[i]=0;
			sigmab[i]=0;
			sigmam[i]=0;
			sigmaAvg[i]=0;
		}
	}
}

template class LinearFitter<Short_t>;
template class LinearFitter<Int_t>;
template class LinearFitter<Float_t>;
template class LinearFitter<Double_t>;
template class LinearFitter<Long64_t>;