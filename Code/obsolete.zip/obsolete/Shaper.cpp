//Shaper.cpp

#include "Shaper.h"

#include "TVirtualFFT.h"
#include "TComplex.h"
#include "TMath.h"

Shaper::Shaper(TF1 *f1, Int_t d){
	setPulse(f1,d);
}

void Shaper::setPulse(TF1 *f1, Int_t d){
	pulse=f1;
	dim=d;
	real.ResizeTo(dim);
	imag.ResizeTo(dim);
	TVirtualFFT *fft=TVirtualFFT::FFT(1,&dim,"R2C");
	for(Int_t i=0;i<dim;i++){
		fft->SetPoint(i,f1->Eval(i));
	}
	fft->Transform();
	for(Int_t i=0;i<dim;i++){
		fft->GetPointComplex(i,real[i],imag[i]);
	}
	delete fft;
}

TVectorD Shaper::shape(const TVectorD &vin,bool conv){
	if(vin.GetNrows()!=dim){
		setPulse(pulse,vin.GetNrows());
	}
	TVectorD vout(dim),real_in(dim),imag_in(dim);
	TVirtualFFT *fft=TVirtualFFT::FFT(1,&dim,"R2C");
	for(Int_t i=0;i<dim;i++){
		fft->SetPoint(i,vin[i]);
	}
	fft->Transform();
	for(Int_t i=0;i<dim;i++){
		fft->GetPointComplex(i,real_in[i],imag_in[i]);
		TComplex a(real[i],imag[i]),b(real_in[i],imag_in[i]),c=conv?b*a:b*TComplex::Conjugate(a)/TMath::Power(TComplex::Abs(a)+1e-15,2);
		real_in[i]=c.Re();
		imag_in[i]=c.Im();
	}
	delete fft;
	fft=TVirtualFFT::FFT(1,&dim,"C2R");
	for(Int_t i=0;i<dim;i++){
		fft->SetPoint(i,real_in[i],imag_in[i]);
	}
	fft->Transform();
	for(Int_t i=0;i<dim;i++){
		vout[i]=fft->GetPointReal(i)/dim;
	}
	delete fft;
	return vout;
}