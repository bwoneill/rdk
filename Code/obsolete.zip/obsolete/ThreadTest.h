//ThreadTest.h

#ifndef THREADTEST_H
#define THREADTEST_H

#include "TThread.h"
#include "TSemaphore.h"
#include "TMutex.h"

class ThreadTest{
private:
	Double_t *data;
	TThread **thread;
	TSemaphore s1,s2;
	TMutex mutex;
	Int_t nextSection;
	const Int_t sections;
	const Int_t N;
	Int_t getNextSection();
	void analyzeSection(Int_t);
	static void *exec(void*);
public:
	ThreadTest(Int_t);
	~ThreadTest();
	void run();
};

#endif