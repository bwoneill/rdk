//GammaFitter.h

#ifndef GAMMAFITTER_H
#define GAMMAFITTER_H

#include "RDKTypes.h"
#include "LinearFitter.h"
#include "E2WFitter.h"

#include <cmath>

class GammaFitter{
private:
	void init();
	void clean();
	void timing();
	LinearFitter<Double_t> lf;
	E2WFitter<Double_t> ef;
	Double_t chi2,p[5];
	Double_t *data;
	const Int_t N;
	static const Double_t C_0,D_0;
public:
	GammaFitter(Int_t n=NPOINTS);
	~GammaFitter();
	void setData(const short*);
	void setData(const Double_t*);
	Int_t optimize();
	inline const Double_t *getParameters() const {return p;}
	inline Double_t getA() const {return p[0];}
	inline Double_t getB() const {return p[1];}
	inline Double_t getC() const {return p[2];}
	inline Double_t getD() const {return p[3];}
	inline Double_t getT() const {return p[4];}
	inline Double_t getE() const {return p[1]*p[3]*pow(p[2]/(p[2]+p[3]),p[2]/p[3])/(p[2]+p[3]);}
	inline Double_t getChi2() const {return chi2+getT()*pow(lf.getSigma(getT()-1),2);}
	inline Double_t getNoise() const {return sqrt(getChi2()/N);}
	inline LinearFitter<Double_t> *getLF(){return &lf;}
	inline E2WFitter<Double_t> *getEF(){return &ef;}
	static Int_t NFIT;
	static Double_t TOLERANCE,STRONG;
	static bool DEBUG;
	Int_t xmin;
	Int_t x,y,z;
};

#endif