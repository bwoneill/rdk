//DataAnalyzer.h

#ifndef DATAANALYZER_H
#define DATAANALYZER_H

#include "RDKTypes.h"

class TSemaphore;

class DataAnalyzer{
protected:
	RawData *data;
	Recon *recon;
public:
	DataAnalyzer(RawData*,Recon*);
	virtual void analyze(Int_t)=0;
};

#endif