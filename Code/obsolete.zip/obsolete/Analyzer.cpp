//Analyzer.cpp

#define DEFINE_CONST

#include "Analyzer.h"
#include "NdatWriter.h"
#include "RDKTools.h"
#include "Header.h"
#include "GammaFitter.h"
#include "SmoothFitter.h"
#include "DeconFitter.h"
#include "RDKReader.h"
#include "TreeReader.h"
#include "RawFileReader.h"

#include "TH1.h"
#include "TF1.h"
#include "TGraph.h"
#include "TMarker.h"
#include "TLine.h"
#include "TLegend.h"
#include "TTree.h"
#include "TFile.h"
#include "TSystem.h"
#include "TThread.h"
#include "TMath.h"
using TMath::Max;

#include <iostream>
using namespace std;

//DeconFitter disabled until further notice

Analyzer::Analyzer(AnalyzerMode m):nseries(-1),nrun(-1){
	initStatic();
	setMode(m);
	reconFile=NULL;reconTree=NULL;
	fitter=new GammaFitter();
	sfitter=new SmoothFitter();
	dfitter=NULL;//new DeconFitter(NPOINTS,"EX");
	reader=new RawFileReader();
}

Analyzer::Analyzer(AnalyzerMode m,Int_t s,Int_t r):nseries(s),nrun(r){
	initStatic();
  setMode(m);
	reconFile=NULL;reconTree=NULL;
	fitter=new GammaFitter();
	sfitter=new SmoothFitter();
	dfitter=NULL;//new DeconFitter(NPOINTS,"EX");
	reader=new RawFileReader();
}

Analyzer::Analyzer(AnalyzerMode m,const Task &task):nseries(task.series)
    ,nrun(task.run){
	initStatic();
  setMode(m);
	reconFile=NULL;reconTree=NULL;
	fitter=new GammaFitter();
	sfitter=new SmoothFitter();
	dfitter=NULL;//new DeconFitter(NPOINTS,"EX");
	reader=new RawFileReader();
}

Analyzer::~Analyzer(){
	clean();
}

void Analyzer::initStatic(){
	if(!f){
		f=new TF1("rdkfit","[0]+[1]*(exp(-[2]*(x-[4]))-exp(-([2]+[3])*(x-[4])))",0,
			NPOINTS*0.04);
	}
	if(!marker){
		marker=new TMarker();
	}
	if(!legend){
		legend=new TLegend(0.5,0.25,0.75,0.5);
	}
	if(!hist){
		hist=new TH1D("rdkgamma","gamma;time (#mus)",NPOINTS,0,NPOINTS*0.04);
	}else{
		hist->Reset("M");
	}
	if(!line){
		line=new TLine();
		line->SetLineColor(kCyan);
	}
}

Int_t Analyzer::run(){
	try{
		if(nseries<=0 || nrun<0){
			throw RDKException("Invalid series or run");
		}
		initFiles();
		//TThread::Printf("Analyzing...");
		analyze();
		//TThread::Lock();
		TThread::Printf("Saving file ss%i/%c%ir%i.root",nseries,type,nseries,nrun);
		reconTree->Write("rdk",TObject::kOverwrite);
		//reconFile->Write(reconTree,"rdk","overwrite");
		//TThread::UnLock();
		return 1;
	}catch(RDKException e){
		if(type=='\0'){
			type='*';
		}
		TString temp;
		temp.Form("Fatal error analyzing ss%i/%c%ir%i files",nseries,type,nseries,nrun);
		TThread::Printf(temp);
		TThread::Printf(e.what());
		return 0;
	}
}

void Analyzer::clean(){
	if(reader){
		delete reader;
	}
	if(reconTree){
		reconTree->Delete();
	}
	if(reconFile){
		reconFile->Close();
	}
	if(fitter){
		delete fitter;
	}
	if(sfitter){
		delete sfitter;
	}
	//if(dfitter){
	//	delete dfitter;
	//}
}

void Analyzer::initFiles(){
	//TThread::Printf("Setting path");
	TString temp;
	temp.Form("%s/ss%i",RDKANAL,nseries);
	type=TreeReader::getRawType(nseries,nrun);
	if(type){
		reader->open(type,nseries,nrun);
		FileStat_t stats;
		//TThread::Printf("Locking");
		TThread::Lock();
		if(gSystem->GetPathInfo(temp,stats)){
			gSystem->mkdir(temp,true);
		}
		//TThread::Printf("Making file");
		TString temp2;
		temp2.Form("%s/%c%ir%i.root",temp.Data(),type,nseries,nrun);
		reconFile=TFile::Open(temp2,"recreate");
		//TThread::Printf("Making tree");
		temp.Form("rdk_%c%ir%i",type,nseries,nrun);
		reconTree=new TTree(temp,"RDK data");
		//TThread::Printf("Recon branch");
		//TThread::Printf("Making string");
		temp.Form("t_e/D:E_e:t_p:E_p:t_gamma[%i]:E_gamma[%i]:chi2_gamma[%i]:R2_gamma[%i]:"
			"fitparam[%i][%i]:nfit[%i]:noise[%i]:t_rise[%i]"
			,NGAMMA,NGAMMA,NGAMMA,NGAMMA,NGAMMA,NPARAM,NGAMMA,NGAMMA,NGAMMA);
		//TThread::Printf("Making branch");
		reconTree->Branch("recon",&recon,temp);
		//TThread::Printf("Entry branch");
		reconTree->Branch("entry",&entry,"timestamp[2]/D:nevent/I:nrun:nseries");
		//TThread::Printf("Unlocking");
		Double_t start=reader->getHeaders()[0].getValue(
			"Running Parameters.Acquisition start time").Atof();
		NdatWriter writer(type,nseries,nrun,start,reconFile);
		writer.write();
		TThread::UnLock();
	}else{
		temp.Form("Unable to type ss%i/*%ir%ib*.dat",nseries,nseries,nrun);
		throw RDKException(temp);
	}
}

void Analyzer::analyze(){
	if(reader){
		while(reader->readNext(entry,rdata)){
			recon_all(rdata,recon);
		}
	}else{
		throw RDKException("Read error: no known source");
	}
}

void Analyzer::recon_all(RawData &rdata,Recon &recon){
	recon_ep(rdata,recon);
	recon_gamma(rdata,recon);
	TThread::Lock();
	reconTree->Fill();
	TThread::UnLock();
}

void Analyzer::recon_ep(RawData &data,Recon &recon,Bool_t debug){
	Int_t t_e=0;
	Double_t E_e=data.ch[NCHANNELS-1][0];
	//recon.t_e=0;
	//recon.E_e=data.ch[NCHANNELS-1][0];
	for(Int_t i=0;i<NPOINTS/2-NFLAT;i++){
		if(data.ch[NCHANNELS-1][i]>E_e){
			E_e=data.ch[NCHANNELS-1][i];
			t_e=i;
		}
	}
	Double_t avg=0;
	Int_t n=0;
	for(Int_t i=0;i<NPOINTS;i++){
		if(fabs(fabs((Double_t)i-t_e)-NPOINTS/4)<NPOINTS/4-NFLAT){
			n++;
			avg+=data.ch[NCHANNELS-1][i];
		}
	}
	avg/=n;
	Int_t t_p=t_e+30;
	Double_t E_p=data.ch[NCHANNELS-1][t_p];
	Bool_t descend=kTRUE;
	Int_t upper=t_e+NPOINTS/2-NFLAT;
	for(Int_t i=t_p;i<upper;i++){
		if(descend && i<NPOINTS-5){
			descend=kFALSE;
			for(Int_t j=1;j<5;j++){
				descend|=data.ch[NCHANNELS-1][i]>data.ch[NCHANNELS-1][i+j];
			}
			E_p=data.ch[NCHANNELS-1][i];
		}else if(data.ch[NCHANNELS-1][i]>E_p){
			E_p=data.ch[NCHANNELS-1][i];
			t_p=i;
		}
	}
	recon.E_e=E_e-avg;
	recon.t_e=t_e;
	recon.E_p=E_p-avg;
	recon.t_p=t_p;
	if(debug){
		for(Int_t i=0;i<NPOINTS;i++){
			hist->SetBinContent(i+1,data.ch[EPCHANNEL][i]);
		}
		hist->Draw();
	}
}

void Analyzer::recon_gamma(RawData &data,Recon &recon,Bool_t debug){
	for(Int_t i=0;i<NGAMMA;i++){
		if(debug){
			cout<<"Photon channel: "<<i<<endl;
		}
		recon_gamma(data,recon,i,debug);
	}
}

Bool_t Analyzer::preanalyze(RawData &data,Recon &recon,Int_t n,Bool_t debug){
	fitter->setData(data.ch[n]);
	Int_t xmax=fitter->getLF()->getXmax(),xmin=fitter->getLF()->getXmin();
	Short_t *sig=data.ch[n];
	if(xmax<=0){
		xmax=1;
	}else if(xmax>=2047){
		xmax=2046;
	}
	if(xmin<=0){
		xmin=1;
	}else if(xmin>=2047){
		xmin=2046;
	}
	Double_t noise=fitter->getLF()->getSigma(NPOINTS-1),max=fitter->getLF()->getMax()
		,flatnoise=fitter->getLF()->getSigma(fitter->xmin)
		,min=fitter->getLF()->getMin()
		,jump=Max(sig[xmax]-(sig[xmax+1]+sig[xmax-1])/2.,(sig[xmin-1]+sig[xmin+1])/2.-sig[xmin]);
	if(debug){
		cout<<"Max: "<<max<<" Min: "<<fitter->getLF()->getMin()<<endl;
		cout<<"Jump: "<<jump<<endl;
		cout<<"xmax: "<<xmax<<" xmin: "<<xmin<<endl;
		cout<<"t: "<<fitter->getT()<<endl;
		cout<<"noise: "<<noise<<" flat noise: "<<flatnoise<<endl;
		cout<<"flat until: "<<fitter->xmin<<endl;
		initStatic();
		for(Int_t i=0;i<NPOINTS;i++){
			hist->SetBinContent(i+1,sig[i]);
			if(i==fitter->getT()){
				cout<<"|";
			}
			if(data.ch[n][i]<=fitter->getA()){
				cout<<"-";
			}else{
				cout<<"+";
			}
		}
		cout<<endl;
		hist->Draw();
	}
	return max<MAX && jump<JUMP && xmax>xmin && xmax>NFLAT && xmax<NPOINTS-2*NFLAT
		&& max-min>300;// && fitter->getT()>NFLAT && fitter->getT()<NPOINTS-2*NFLAT
		//&& fitter->xmin<NPOINTS-NFLAT && abs(fitter->xmin-fitter->getT())<2*NFLAT
		//&& noise>1.2*flatnoise;
}

void Analyzer::recon_gamma(RawData &data,Recon &recon,Int_t n,Bool_t debug){
	if(mode==kFit){
		if(preanalyze(data,recon,n,debug)){
			recon.nfit[n]=fitter->optimize();
			Double_t param[5];
			for(Int_t i=0;i<5;i++){
				recon.fitparam[n][i]=fitter->getParameters()[i];
				if(i<2){
					param[i]=fitter->getParameters()[i];
				}else if(i<4){
					param[i]=fitter->getParameters()[i]/0.04;
				}else{
					param[i]=fitter->getParameters()[i]*0.04;
				}
			}
			recon.E_gamma[n]=fitter->getE();
			recon.t_gamma[n]=fitter->getT();
			recon.chi2_gamma[n]=fitter->getChi2();
			recon.R2_gamma[n]=fitter->getEF()->getR2();
			recon.noise[n]=fitter->getNoise();
			recon.t_rise[n]=fitter->getLF()->getXmax()-recon.t_gamma[n];
			if(debug){
				legend->Clear();
				const Char_t *list[5]={"A","B","C","D","t"};
				for(Int_t i=0;i<5;i++){
					TString temp;
					temp.Form("%s=%f",list[i],param[i]);
					legend->AddEntry(f,temp,"");
				}
				TString temp;
				temp.Form("E=%f",recon.E_gamma[n]);
				legend->AddEntry(f,temp,"");
				f->SetRange((recon.t_gamma[n]-1)*0.04,NPOINTS*0.04);
				f->SetLineColor(kRed);
				f->SetParameters(param);
				f->Draw("same");
				marker->SetX(fitter->getT()*0.04);
				marker->Draw("same");
				hist->Draw("same");
				legend->Draw("same");
				line->SetX1(recon.t_gamma[n]*0.04);
				line->SetX2(recon.t_gamma[n]*0.04);
				line->SetY1(hist->GetYaxis()->GetXmin());
				line->SetY2(hist->GetYaxis()->GetXmax());
				line->Draw("same");
				cout<<"E_gamma="<<recon.E_gamma[n]<<endl;
				cout<<"t_gamma="<<recon.t_gamma[n]<<endl;
				cout<<"chi2="<<recon.chi2_gamma[n]<<endl;
				cout<<"R2="<<recon.R2_gamma[n]<<endl;
				cout<<"noise="<<recon.noise[n]<<endl;
				cout<<"SNR="<<10*log10(recon.E_gamma[n]/recon.noise[n])<<"dB"<<endl;
				cout<<"nfit="<<recon.nfit[n]<<endl;
				cout<<"A="<<fitter->getA()<<" B="<<fitter->getB()<<" C="<<fitter->getC()<<" D="<<fitter->getD()<<endl;
			}
		}else{	
			recon.E_gamma[n]=0;
			recon.t_gamma[n]=0;
			recon.chi2_gamma[n]=0;
			recon.noise[n]=0;
			for(Int_t i=0;i<5;i++){
				recon.fitparam[n][i]=0;
			}
		}
	}else if(mode==kSmooth){
		if(preanalyze(data,recon,n,debug)){
			TVectorD v(NPOINTS);
			for(Int_t i=0;i<NPOINTS;i++){
				v[i]=data.ch[n][i];
			}
			sfitter->fit(v,kFALSE);
			Double_t max=sfitter->getMax(),xmax=sfitter->getXmax();
			recon.t_gamma[n]=0;
			recon.E_gamma[n]=0;
			for(Int_t i=sfitter->getXmax();i>64 && recon.t_gamma[n]==0;i--){
				Int_t j=i-32;
				Double_t m=fitter->getLF()->getM(j),b=fitter->getLF()->getB(j);
				Double_t min=b+m*i,E=max-b-m*xmax,th=0.1*E+min;
				if(sfitter->getV4()[i]<th){
					recon.t_gamma[n]=i+1;
					recon.E_gamma[n]=E;
				}
			}
			//recon.E_gamma[n]=sfitter->getEnergy();
			//recon.t_gamma[n]=fitter->getT();
			//recon.t_gamma[n]=sfitter->getT();
			//recon.t_gamma[n]=sfitter->getT10();
			recon.chi2_gamma[n]=0;
			recon.R2_gamma[n]=0;
			recon.noise[n]=fitter->getLF()->getSigma(recon.t_gamma[n]);
			recon.nfit[n]=-1;
			recon.t_rise[n]=xmax-recon.t_gamma[n];
			//recon.t_rise[n]=sfitter->getT90()-sfitter->getT10();
			for(Int_t i=0;i<5;i++){
				recon.fitparam[n][i]=0;
			}
			if(debug){
				cout<<"Max: "<<max<<endl;
				cout<<"xMax: "<<xmax<<endl;
				//cout<<"t: "<<sfitter->getT()<<endl;
				//cout<<"t10: "<<sfitter->getT10()<<endl;
				//cout<<"t90: "<<sfitter->getT90()<<endl;
				legend->Clear();
				if(g4){
					delete g4;
				}
				if(g64){
					delete g64;
				}
				TVectorD xaxis(NPOINTS);
				for(Int_t i=0;i<NPOINTS;i++){
					xaxis[i]=0.04*i;
				}
				g4=new TGraph(xaxis,sfitter->getV4());
				g64=new TGraph(xaxis,sfitter->getV64());
				g4->SetLineColor(kGreen);
				g64->SetLineColor(kRed);
				TString temp;
				temp.Form("t=%f",recon.t_gamma[n]*0.04);
				legend->AddEntry(g4,temp);
				temp.Form("E=%f",recon.E_gamma[n]);
				legend->AddEntry(g64,temp);
				hist->Draw();
				g4->Draw("l");
				g64->Draw("l");
				line->SetX1(recon.t_gamma[n]*0.04);
				line->SetX2(recon.t_gamma[n]*0.04);
				line->SetY1(sfitter->getMin());
				line->SetY2(max);
				line->Draw("same");
				legend->Draw("same");
			}
		}else{
			recon.E_gamma[n]=0;
			recon.t_gamma[n]=0;
			recon.chi2_gamma[n]=0;
			recon.noise[n]=0;
			for(Int_t i=0;i<5;i++){
				recon.fitparam[n][i]=0;
			}
		}
	}else if(mode==kDecon){
		cerr<<"Decon mode disabled until further notice"<<endl;
		//dfitter->setData(data.ch[n]);
		//dfitter->fit(n==2 || n==6 || n==13?kBAPD:kBGO);
		//recon.E_gamma[n]=dfitter->getE();
		//recon.t_gamma[n]=dfitter->getT();
		//recon.chi2_gamma[n]=-1;
		//recon.noise[n]=0;
		//for(Int_t i=0;i<5;i++){
		//	recon.fitparam[n][i]=0;
		//}
		//if(debug){
		//	cout<<"E_gamma: "<<dfitter->getE()<<endl;
		//	cout<<"t_gamma: "<<dfitter->getT()<<endl;
		//}
	}
}

TH1 *Analyzer::hist=NULL;
TGraph *Analyzer::g4=NULL;
TGraph *Analyzer::g64=NULL;
TLine *Analyzer::line=NULL;
TF1 *Analyzer::f=NULL;
TMarker *Analyzer::marker=NULL;
TLegend *Analyzer::legend=NULL;

Double_t Analyzer::NOISE=70;
Double_t Analyzer::FLATNOISE=80;
Double_t Analyzer::UNCERTAINTY=10;
Double_t Analyzer::JUMP=200;
Double_t Analyzer::MAX=MAXHEIGHT;
AnalyzerMode Analyzer::MODE=kSmooth;
Int_t Analyzer::EPCHANNEL=15;