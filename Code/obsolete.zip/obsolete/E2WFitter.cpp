//E2WFitter.cpp

#include "E2WFitter.h"

#include <cmath>

template<class K> E2WFitter<K>::E2WFitter(Int_t n):N(n){
	A=0;B=0;C=0;D=0;T=0;
	chi2=0;wChi2=0;R2=0;
	deltaC=0;deltaD=0;deltaT=0;
	W=new Double_t[N];
	resetW();
}

template<class K> E2WFitter<K>::~E2WFitter(){
	delete[] W;
}

template<class K> void E2WFitter<K>::fit(const K* data){
	const Double_t F=C+D;
	Double_t sum_y=0,sum_y2=0,sum_z2=0,sum_zy=0,tr_W=0;
	Double_t uwsum_y2=0,uwsum_z2=0,uwsum_zy=0;
	Double_t alpha_11=0,alpha_12=0,alpha_22=0;
	Double_t gamma_1y=0,gamma_2y=0,gamma_1z=0,gamma_2z=0;
	for(Int_t i=0;i<N-T;i++){
		Double_t y=data[i+(Int_t)T]-A,eCi=exp(-C*i),eDi=exp(-D*i),eFi=exp(-F*i),z=eCi*(1-eDi),a=exp(-F*i);
		Double_t dzdC=-i*z,dzdD=i*a,dzdT=C*eCi-F*eFi;
		Double_t w=WEIGHTED?W[i]:1;
		sum_y+=w*y;
		sum_y2+=w*y*y;
		sum_z2+=w*z*z;
		sum_zy+=w*z*y;
		uwsum_y2+=y*y;
		uwsum_z2+=z*z;
		uwsum_zy+=z*y;
		tr_W+=w;
		alpha_11+=i*i*exp(-2*C*i);
		alpha_12+=i*i*exp(-(C+F)*i);
		alpha_22+=i*i*exp(-2*F*i);
		gamma_1y+=i*y*eCi;
		gamma_2y+=i*y*eFi;
		gamma_1z+=i*z*eCi;
		gamma_2z+=i*z*eFi;
	}
	B=sum_zy/sum_z2;
	wChi2=sum_y2-sum_zy*sum_zy/sum_z2;
	chi2=uwsum_y2-uwsum_zy*uwsum_zy/uwsum_z2;
	R2=1-wChi2/(sum_y2-sum_y*sum_y/tr_W);
	Double_t det=alpha_11*alpha_22-alpha_12*alpha_12;
	deltaC=(alpha_12*(gamma_2y-B*gamma_2z)-alpha_22*(gamma_1y-B*gamma_1z))/B/det;
	deltaD=((alpha_11-alpha_12)*(gamma_2y-B*gamma_2z)-(alpha_12-alpha_22)*(gamma_1y-B*gamma_1z))/B/det;
	deltaT=0;
	for(Int_t i=0;i<N-T;i++){
		Double_t r=data[i+(Int_t)T]-A-B*exp(-C*i)*(1-exp(-D*i));
		W[i]=1/(fabs(r)+DELTA);
	}
}

template<class K> void E2WFitter<K>::resetW(){
	for(Int_t i=0;i<N;i++){
		W[i]=1;
	}
}

template<class K> Double_t E2WFitter<K>::DELTA=1e-5;
template<class K> bool E2WFitter<K>::WEIGHTED=true;

template class E2WFitter<short>;
template class E2WFitter<Int_t>;
template class E2WFitter<Float_t>;
template class E2WFitter<Double_t>;