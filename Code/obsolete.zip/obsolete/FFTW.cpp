//FFTW.cpp

#include "FFTW.h"
#include "fftw3.h"
#include <fstream>
using namespace std;

void FFTW::exportWisdom(TString out){
	TString wisdom(fftw_export_wisdom_to_string());
	ofstream outFile(out.Data());
	outFile<<wisdom;
	outFile.close();
}

void FFTW::importWisdom(TString in){
	ifstream inFile(in.Data());
	TString wisdom;
	wisdom.ReadFile(inFile);
	inFile.close();
	fftw_import_wisdom_from_string(wisdom.Data());
}

void FFTW::forgetWisdom(){
	fftw_forget_wisdom();
}