//EFitter.cpp

#include "EFitter.h"

template class EFitter<Short_t>;
template class EFitter<Int_t>;
template class EFitter<Float_t>;
template class EFitter<Double_t>;