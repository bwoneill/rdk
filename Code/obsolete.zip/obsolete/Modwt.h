//Modwt.h

#ifndef MODWT_H
#define MODWT_H

#include <vector>

class Modwt{
private:
	unsigned int length,depth,L;
	std::vector<double> v,w,d,s,h,g,zero;
	void downstep(unsigned int,const std::vector<double>&,
		std::vector<double>&,std::vector<double>&);
	void upstep(unsigned int,const std::vector<double>&,
		const std::vector<double>&,std::vector<double>&);
public:
	Modwt(unsigned int);
	Modwt(unsigned int,const std::vector<double>&);
	~Modwt();
	void setWavelet(const std::vector<double>&);
	void transform(const std::vector<double>&);
	void itransform(std::vector<double>&);
	std::vector<double>& getV(){return v;}
	std::vector<double>& getW(){return w;}
	std::vector<double>& getD(){return d;}
	std::vector<double>& getS(){return s;}
	std::vector<double>& getH(){return h;}
	std::vector<double>& getG(){return g;}
};

#endif