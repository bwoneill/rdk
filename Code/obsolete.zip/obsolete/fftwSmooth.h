//fftwSmooth.h

#ifndef FFTWSMOOTH_H
#define FFTWSMOOTH_H

#include "TString.h"
#include "TComplex.h"
#include "TVirtualFFT.h"

class fftwSmooth{
private:
	TVirtualFFT *r2c,*c2r;
	TComplex *smoother;
	Int_t npoints;
	Double_t radius;
public:
	fftwSmooth(Int_t,Double_t,TString="");
	~fftwSmooth();
	void smooth(Double_t *);
};

#endif