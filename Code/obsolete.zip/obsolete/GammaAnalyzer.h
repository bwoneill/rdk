//GammaAnalyzer.h

#ifndef GAMMAANALYZER_H
#define GAMMAANALYZER_H

#include "DataAnalyzer.h"

#include "TVectorD.h"

class Smoother;

class GammaAnalyzer:public DataAnalyzer{
	Smoother *smoother,*eSmoother;
	TVectorD y,y1,y2;
	Double_t m[2048],b[2048],sigma[2048];
	//Double_t chi2[2048],R2[2048],sigmab[2048],sigmam[2048],sigmaAvg[2048];
	Int_t n;
public:
	GammaAnalyzer(RawData*,Recon*,Int_t);
	~GammaAnalyzer();
	void analyze(Int_t);
};

#endif