//E2Fitter2.cpp

#include "E2Fitter2.h"
#include "RDKTools.h"
#include "TString.h"
#include "TFitResultPtr.h"

E2Fitter2::E2Fitter2(Int_t n,Double_t *X):EFitter<Double_t>(n),status(0),debug(kFALSE){
	NFITS++;
	TString name;
	graph=new TGraph(N);
	xaxis=new Double_t[N];
	if(X){
		for(Int_t i=0;i<N;i++){
			xaxis[i]=X[i];
		}
	}else{
		for(Int_t i=0;i<N;i++){
			xaxis[i]=i;
		}
	}
	name.Form("fit%i",NFITS);
	f=new TF1(name.Data(),fitFunction,xaxis[0],xaxis[N-1],5);
	f->SetParLimits(1,0,1e5);
	f->SetParLimits(2,1e-5,1e-1);
	f->SetParLimits(3,1e-5,1e-1);
	f->SetParLimits(4,0,xaxis[N-1]);
	par=new Double_t[5];
	resetParameters();
}

E2Fitter2::~E2Fitter2(){
	delete[] par;
	delete[] xaxis;
	delete graph;
	delete f;
}

void E2Fitter2::fit(const Double_t *y){
	f->SetParameters(par);
	for(Int_t i=0;i<N;i++){
		graph->SetPoint(i,xaxis[i],y[i]);
	}
	result=graph->Fit(f,debug?"QNRBS":"QNRB");
	status=result;
	f->GetParameters(par);
	A=par[0];
	B=par[1];
	C=par[2];
	D=par[3];
	T=par[4];
	chi2=f->GetChisquare();
}

void E2Fitter2::setParameters(Double_t *p){
	for(Int_t i=0;i<5;i++){
		par[i]=p[i];
	}
}

void E2Fitter2::resetParameters(){
	par[0]=1;
	par[1]=1e3;
	par[2]=1e-3;
	par[4]=1e-3;
	par[5]=xaxis[N-1]/2;
}

Int_t E2Fitter2::NFITS=0;