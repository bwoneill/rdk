//Analyzer.h

#ifndef ANALYZER_H
#define ANALYZER_H

#include "RDKTypes.h"
#include "Runnable.h"
class GammaFitter;
class SmoothFitter;
class DeconFitter;
class RawFileReader;

class TH1;
class TF1;
class TGraph;
class TLine;
class TMarker;
class TLegend;
class TFile;
class TTree;

class Analyzer: public Runnable{
private:
	static void initStatic();
	void initFiles();
	void analyze();
	void recon_all(RawData&,Recon&);
	bool preanalyze(RawData&,Recon&,Int_t,Bool_t=kFALSE);
	GammaFitter *fitter;
	SmoothFitter *sfitter;
	DeconFitter *dfitter;
	TFile *reconFile;
	TTree *reconTree;
	Recon recon;
	Entry entry;
	RawData rdata;
	RawFileReader *reader;
	const Int_t nseries,nrun;
	AnalyzerMode mode;
	Char_t type;
public:
	static AnalyzerMode MODE;
	Analyzer(AnalyzerMode=MODE);
	Analyzer(AnalyzerMode,Int_t,Int_t);
	Analyzer(AnalyzerMode,const Task&);
	~Analyzer();
	void recon_ep(RawData&,Recon&,Bool_t=kFALSE);
	void recon_gamma(RawData&,Recon&,Bool_t=kFALSE);
	void recon_gamma(RawData&,Recon&,Int_t,Bool_t=kFALSE);
	void setMode(AnalyzerMode m){mode=m;}
	Int_t run();
	void clean();
	static TH1 *hist;
	static TGraph *g4,*g64;
	static TLine *line;
	static TF1 *f;
	static TMarker *marker;
	static TLegend *legend;
	static Double_t NOISE,FLATNOISE,UNCERTAINTY,JUMP,MAX;
	static Int_t EPCHANNEL;
};

#endif