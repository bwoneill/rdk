//E2WFitter.h

#ifndef E2WFITTER_H
#define E2WFITTER_H

#include "RDKTypes.h"

#include <cmath>

template<class K> class E2WFitter{
private:
	Double_t *W;
	bool init;
	Double_t A,B,C,D,T,chi2,R2,wChi2;
	Double_t deltaC,deltaD,deltaT;
	const Int_t N;
public:
	E2WFitter(Int_t n=NPOINTS);
	~E2WFitter();
	void fit(const K*);
	void next(){C+=deltaC;D+=deltaD;}
	void resetW();
	inline Double_t getWChi2(){return wChi2;}
	static Double_t DELTA;
	static bool WEIGHTED;
	inline void setOffset(Double_t a){A=a;}
	inline void setTime(Double_t t){T=t;}
	inline void setParameters(Double_t c,Double_t d){C=c;D=d;}
	inline Double_t getA() const {return A;}
	inline Double_t getB() const {return B;}
	inline Double_t getC() const {return C;}
	inline Double_t getD() const {return D;}
	inline Double_t getT() const {return T;}
	inline Double_t getR2() const {return R2;}
	inline Double_t getChi2() const {return chi2;}
	inline Double_t getNoise() const {return sqrt(chi2/(N-T));}
	inline Double_t getDeltaC() const {return deltaC;}
	inline Double_t getDeltaD() const {return deltaD;}
	inline Double_t getDeltaT() const {return deltaT;}
};

#endif