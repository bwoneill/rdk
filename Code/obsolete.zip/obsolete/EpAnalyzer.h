//EpAnalyzer.h

#ifndef EPANALYZER_H
#define EPANALYZER_H

#include "DataAnalyzer.h"

class TSemaphore;

class EpAnalyzer:public DataAnalyzer{
public:
	EpAnalyzer(RawData*,Recon*);
	~EpAnalyzer();
	void analyze(Int_t);
};

#endif