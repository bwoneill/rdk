//GammaFitter2.h

#ifndef GAMMAFITTER2_H
#define GAMMAFITTER2_H

#include "RDKTypes.h"
#include "E2Fitter2.h"

class GammaFitter2{
private:
	E2Fitter2 *full,*limited;
public:
	static Bool_t BENCHMARK,PRINT;
	enum kType {kFULL,kLIMITED};
	GammaFitter2(Int_t,Int_t,Double_t*);
	~GammaFitter2();
	void fit(const Short_t*);
	void fit(const Double_t*);
	Double_t getE() const;
	inline Double_t getT() const {return full->getParameters()[4];}
	Double_t getChi2(kType=kFULL) const;
	Double_t *getParameters(kType=kFULL) const;
	TFitResultPtr getResult(kType=kFULL) const;
	void setDebug(Bool_t);
};

#endif