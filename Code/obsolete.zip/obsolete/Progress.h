// Progress.h

#ifndef PROGRESS_H
#define PROGRESS_H

#include "TGProgressBar.h"
#include "TGFrame.h"

class Progress {
	public:
		TGHProgressBar *p;
		TGMainFrame *frame;
		Float_t MAX;
	public:
		Progress(const Char_t*,Float_t=100);
		Progress(Float_t max=100){Progress("Progress...",max);}
		~Progress();
		void start();
		void set(Float_t i);
		inline void setMax(Float_t m){MAX=m;p->SetRange(0,m);}
		inline Float_t get() const {return p->GetPosition();}
		inline Float_t getMax() const {return p->GetMax();}
};

#endif