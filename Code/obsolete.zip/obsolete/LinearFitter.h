//LinearFitter.h

#ifndef LINEARFITTER_H
#define LINEARFITTER_H

#include "RDKTypes.h"

#include <cmath>

template<class T> class LinearFitter{
	private:
		Double_t *R2,*m,*b,*sigma,*chi2,*sigmab,*sigmam,*sigmaAvg;
		Double_t max,min;
		const Int_t n;
		Int_t xmax,xmin;
	public:
		LinearFitter(Int_t=NPOINTS);
		~LinearFitter();
		void fit(const T*);
		inline const Double_t *getR2() const {return R2;}
		inline Double_t getR2(Int_t x) const {return R2[x];}
		inline const Double_t *getM() const {return m;}
		inline Double_t getM(Int_t x) const {return m[x];}
		inline const Double_t *getSigmaM() const {return sigmam;}
		inline Double_t getSigmaM(Int_t x) const {return sigmam[x];}
		inline const Double_t *getB() const {return b;}
		inline Double_t getB(Int_t x) const {return b[x];}
		inline const Double_t *getSigmaB() const {return sigmab;}
		inline Double_t getSigmaB(Int_t x) const {return sigmab[x];}
		inline const Double_t *getChi2() const {return chi2;}
		inline Double_t getChi2(Int_t x) const {return chi2[x];}
		inline const Double_t *getSigma() const {return sigma;}
		inline Double_t getSigma(Int_t x) const {return sigma[x];}
		inline Double_t getMax() const {return max;}
		inline Double_t getMin() const {return min;}
		inline Double_t getN() const {return n;}
		inline Int_t getXmax() const {return xmax;}
		inline Int_t getXmin() const {return xmin;}
		inline Double_t getY(Int_t x) const {return m[x]*x+b[x];}
		inline Double_t getSigmaY(Int_t x) const {return sqrt(sigmab[x]*sigmab[x]+sigmam[x]*sigmam[x]*x*x);}
		inline Double_t getAvg(Int_t x) const {return m[x]*x/2+b[x];}
		inline Double_t getSigmaAvg(Int_t x) const {return sigmaAvg[x];}
		inline const Double_t *getSigmaAvg() const {return sigmaAvg;}
		inline Double_t getNoise(Int_t x) const {return sqrt(chi2[x]/(x+1));}
};

#endif