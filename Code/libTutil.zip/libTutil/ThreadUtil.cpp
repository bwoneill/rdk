//ThreadUtil.cpp

#define TUDLL __declspec(dllexport)
#include "ThreadUtil.h"
#include "Buffer.h"
#include "Data.h"
#include "Queue.h"

#include "TThread.h"
#include "TString.h"

using namespace tutil;

#include <iostream>
using namespace std;

ThreadUtil::ThreadUtil(Reader *r,Writer *w,Analyzer **a,Int_t n,
											 UInt_t qmin,UInt_t qmax,UInt_t bmax){
	this->n=n;
	this->qmin=qmin;
	this->qmax=qmax;
	this->bmax=bmax;
	reader=r;
	writer=w;
	analyzer=a;
	q=new Queue(reader,qmin,qmax);
	buff=new Buffer(writer,bmax);
	threads=new TThread*[n];
	for(Int_t i=0;i<n;i++){
		TString temp;
		temp.Form("core%i",i);
		threads[i]=new TThread(temp,(void(*)(void*))&exec,this);
	}
}

ThreadUtil::~ThreadUtil(){
	delete q;
	delete buff;
	for(Int_t i=0;i<n;i++){
		threads[i]->Delete();
	}
}

void ThreadUtil::run(){
	//TThread::Printf("Opening reader");
	reader->open();
	//TThread::Printf("Opening writer");
	writer->open();
	//TThread::Printf("Starting threads");
	for(Int_t i=0;i<n;i++){
		cout<<i<<endl;
		threads[i]->Run();
	}
	Bool_t running=kFALSE;
	//TThread::Printf("Waiting");
	do{
		TThread::Sleep(0,1000000ll);
		for(Int_t i=0;i<n;i++){
			if(threads[i]){
				running|=(threads[i]->GetState()==TThread::kRunningState);
			}
		}
		//TThread::Printf(running?"Still waiting":"Done!");
	}while(running);
	//TThread::Printf("Flushing");
	buff->flush(kTRUE);
	//TThread::Printf("Closing reader");
	reader->close();
	//TThread::Printf("Closing writer");
	writer->close();
	//TThread::Printf("done");
}

void* ThreadUtil::exec(void *arg){
	ThreadUtil *tu=(ThreadUtil*)arg;
	Int_t thID=-1;
	for(Int_t i=0;i<tu->n;i++){
		if(tu->threads[i]==TThread::Self()){
			thID=i;
		}
	}
	if(thID>=0){
		Input *input=0;
		while(tu->q->pop(input)){
			Output *output=tu->analyzer[thID]->analyze(input);
			tu->buff->push(output);
		}
	}else{
		TThread::Printf("bugger");
	}
	return NULL;
}

void* ThreadUtil::clean(void *arg){
	ThreadUtil *tu=(ThreadUtil*)arg;
	Int_t thID=-1;
	for(Int_t i=0;i<tu->n;i++){
		if(tu->threads[i]==TThread::Self()){
			thID=i;
		}
	}
	if(thID>=0){
		tu->threads[thID]->Delete();
		tu->threads[thID]=NULL;
	}
	return NULL;
}