#include "Buffer.h"
#include "Data.h"

#include "TMutex.h"

using namespace tutil;

Buffer::Buffer(Writer *w,UInt_t max){
	this->max=max;
	writer=w;
	mutex=new TMutex(kTRUE);
	index=-1;
}

Buffer::~Buffer(){
	delete mutex;
}

void Buffer::push(Output *output){
	mutex->Lock();
	buff.push_back(output);
	flush();
	mutex->UnLock();
}

void Buffer::flush(Bool_t forced){
	mutex->Lock();
	buff.sort();
	while(buff.size()>0 && (buff.front()->index()-index==1 || forced)){
		Output *next=buff.front();
		writer->write(next);
		index=next->index();
		buff.pop_front();
	}
	if(buff.size()>max){
		flush(kTRUE);
	}
	mutex->UnLock();
}

Bool_t Buffer::empty(){
	return buff.empty();
}