//ThreadBeta.h

#ifndef THREADBETA_H
#define THREADBETA_H

#ifndef __ROOTCINT__
#include "../libTutil/Data.h"
#else
namespace tutil{
	class Input;
	class Output;
	class Reader;
	class Writer;
	class Analyzer;
}
#endif

#include "TString.h"
#include "TRandom.h"
#include <vector>

class ThreadUtil;

class StringInput:public tutil::Input{
public:
	StringInput(const Char_t*,Long64_t);
	~StringInput(){}
	TString data;
	ULong64_t& index(){return idx;}
};

class StringOutput:public tutil::Output{
public:
	StringOutput(const Char_t*,Long64_t);
	~StringOutput(){}
	TString data;
	ULong64_t& index(){return idx;}
};

class StringReader:public tutil::Reader{
private:
	Int_t n,c;
	std::vector<StringInput*> data;
public:
	StringReader(Int_t);
	~StringReader(){}
	tutil::Input* read();
	Bool_t eof()const;
	void open();
	void close();
	StringInput* getData(Int_t i){return data[i];}
};

class StringWriter:public tutil::Writer{
private:
	std::vector<StringOutput*> data;
public:
	StringWriter();
	~StringWriter(){}
	void write(tutil::Output*);
	void open();
	void close();
	StringOutput* getData(Int_t i){return data[i];}
	Int_t getN(){return data.size();}
};

class StringAnalyzer:public tutil::Analyzer{
private:
	TRandom *rand;
public:
	StringAnalyzer();
	~StringAnalyzer(){delete rand;}
	tutil::Output* analyze(tutil::Input*);
};

class StringTest{
private:
	ThreadUtil *runner;
	StringReader *reader;
	StringWriter *writer;
	tutil::Analyzer **analyzer;
public:
	StringTest();
	~StringTest();
	void run();
};

#endif