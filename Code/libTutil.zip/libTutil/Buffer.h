#ifndef TUBUFFER_H
#define TUBUFFER_H

#include <list>

#include "Rtypes.h"

class TMutex;
class ThreadUtil;

namespace tutil{
	class Output;
	class Writer;

	class Buffer{
	private:
		std::list<Output*> buff;
		Writer *writer;
		TMutex *mutex;
		UInt_t max;
		ULong64_t index;
	public:
		Buffer(Writer*,UInt_t);
		~Buffer();
		void push(Output*);
		void flush(Bool_t=kFALSE);
		Bool_t empty();
	};
};

#endif