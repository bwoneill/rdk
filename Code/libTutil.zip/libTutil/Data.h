#ifndef TUDATA_H
#define TUDATA_H

#include "Rtypes.h"

namespace tutil{
	class Input{
	protected:
		ULong64_t idx;
	public:
		virtual ~Input(){}
		ULong64_t index()const{return idx;}
	};

	class Output{
	protected:
		ULong64_t idx;
	public:
		virtual ~Output(){}
		virtual Bool_t operator<(const Output *a)const{return idx<a->idx;}
		ULong64_t index()const{return idx;}
	};

	class Reader{
	public:
		virtual ~Reader(){}
		virtual Input* read()=0;
		virtual Bool_t eof()const=0;
		virtual void open()=0;
		virtual void close()=0;
	};

	class Writer{
	public:
		virtual ~Writer(){}
		virtual void write(Output*)=0;
		virtual void open()=0;
		virtual void close()=0;
	};

	class Analyzer{
	public:
		virtual ~Analyzer(){}
		virtual Output *analyze(Input*)=0;
	};
};

#endif