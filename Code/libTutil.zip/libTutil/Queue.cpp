#include "Queue.h"
#include "Data.h"

#include "TMutex.h"

using namespace tutil;

Queue::Queue(Reader *r,UInt_t min,UInt_t max){
	this->min=min;
	this->max=max;
	reader=r;
	mutex=new TMutex();
}

Queue::~Queue(){
	delete mutex;
}

Bool_t Queue::pop(Input *input){
	mutex->Lock();
	if(q.size()<=min && !reader->eof()){
		while(q.size()<max && !reader->eof()){
			Input *temp=reader->read();
			q.push(temp);
		}
	}
	Bool_t  filled=!q.empty();
	if(filled){
		input=q.front();
		q.pop();
	}else{
		input=0;
	}
	mutex->UnLock();
	return filled;
}

Bool_t Queue::empty()const{
	mutex->Lock();
	Bool_t isEmpty=q.empty() && reader->eof();
	mutex->UnLock();
	return isEmpty;
}