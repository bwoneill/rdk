#ifndef THREADUTIL_H
#define THREADUTIL_H

#ifndef TUDLL
#define TUDLL
#endif

#include "Rtypes.h"

class TThread;

namespace tutil{
	class Input;
	class Output;
	class Analyzer;
	class Reader;
	class Writer;
	class Queue;
	class Buffer;
};

class TUDLL ThreadUtil{
private:
	tutil::Reader *reader;
	tutil::Writer *writer;
	tutil::Analyzer **analyzer;
	tutil::Queue *q;
	tutil::Buffer *buff;
	Int_t n;
	UInt_t qmin,qmax,bmax;
	TThread **threads;
public:
	ThreadUtil(tutil::Reader*,tutil::Writer*,tutil::Analyzer**,Int_t,
		UInt_t,UInt_t,UInt_t);
	~ThreadUtil();
	void run();
	static void* exec(void*);
	static void* clean(void*);
};

#undef TUDLL

#endif