//ThreadBeta.cpp

#include "../libTutil/ThreadUtil.h"
#include "ThreadBeta.h"
#include "TThread.h"
#include <iostream>
using namespace std;
using namespace tutil;

StringInput::StringInput(const Char_t *str, Long64_t i){
	idx=i;
	data=str;
}

StringOutput::StringOutput(const Char_t *str, Long64_t i){
	idx=i;
	data=str;
}

StringReader::StringReader(Int_t n){
	c=0;
	this->n=n;
}

void StringReader::open(){
	for(Int_t i=0;i<n;i++){
		TString temp;
		temp.Form("test string %i",n);
		StringInput *input=new StringInput(temp,n);
		data.push_back(input);
	}
}

void StringReader::close(){
}

Bool_t StringReader::eof()const{
	return c>=data.size();
}

Input *StringReader::read(){
	StringInput *result;
	if(eof()){
		result=NULL;
	}else{
		result=data[c];
		c++;
	}
	return result;
}

StringWriter::StringWriter(){
}

void StringWriter::write(Output *out){
	StringOutput *temp=(StringOutput*)out;
	data.push_back(temp);
}

void StringWriter::open(){
}

void StringWriter::close(){
}

StringAnalyzer::StringAnalyzer(){
	rand=new TRandom();
}

Output* StringAnalyzer::analyze(Input *in){
	StringOutput *result;
	if(in==NULL){
		result=NULL;
	}else{
		StringInput *sin=(StringInput*)in;
		TString temp=sin->data;
		temp.Form("analyzed %s",temp.Data());
		TThread::Sleep(0,rand->Integer(100));
		result=new StringOutput(temp,sin->index());
	}
	return result;
}

StringTest::StringTest(){
	reader=new StringReader(200);
	writer=new StringWriter();
	analyzer=new tutil::Analyzer*[10];
	for(Int_t i=0;i<10;i++){
		analyzer[i]=new StringAnalyzer();
	}
	runner=new ThreadUtil(reader,writer,analyzer,10,0,100,100);
}

StringTest::~StringTest(){
	delete reader;
	delete writer;
	delete[] analyzer;
	delete runner;
}

void StringTest::run(){
	if(reader==NULL || writer==NULL){
		cout<<"WTF?"<<endl;
		return;
	}
	runner->run();
	cout<<"i\tInput string\tOutput string"<<endl;
	if(reader==NULL){
		cout<<"Reader does not exist"<<endl;
	}
	if(writer==NULL){
		cout<<"Writer does not exist"<<endl;
	}
	if(reader==NULL || writer==NULL){
		return;
	}
	for(Int_t i=0;i<100 && i<writer->getN();i++){
		StringInput *in=reader->getData(i);
		StringOutput *out=writer->getData(i);
		cout<<i<<'\t'<<in->data<<'\t'<<out->data<<endl;
	}
}