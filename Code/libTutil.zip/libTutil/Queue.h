#ifndef TUQUEUE_H
#define TUQUEUE_H

#include <queue>

#include "Rtypes.h"

class TMutex;
class ThreadUtil;

namespace tutil{
	class Input;
	class Reader;

	class Queue{
	private:
		TMutex *mutex;
		std::queue<Input*> q;
		Reader *reader;
		UInt_t max,min;
	public:
		Queue(Reader*,UInt_t,UInt_t);
		~Queue();
		Bool_t pop(Input*);
		Bool_t empty() const;
	};
};

#endif