//Cudwt.h

#ifndef CUDWT_H
#define CUDWT_H

class Cudwt{
private:
	size_t length,size,log2length;
	float *_in;
	float *_out;
public:
	Cudwt(unsigned int);
	~Cudwt();
	void dwtHaar(const float *,float*);
	void idwtHaar(const float *,float*);
};

#endif